"""Apply alembic t6a7b8c9d0e1 on data_asset_test via tunnel, then run pytest.

Reads DB password from server env via SSH. Does not print secrets.
Writes summary to scripts/_m1m2_pytest_summary.txt
"""
from __future__ import annotations

import os
import re
import select
import socket
import socketserver
import subprocess
import sys
import threading
import time
import urllib.parse
from pathlib import Path

import paramiko
from sqlalchemy import create_engine, text

BACKEND = Path(__file__).resolve().parents[1]
SUMMARY = Path(__file__).resolve().parent / "_m1m2_pytest_summary.txt"
VENV_PY = BACKEND / ".venv" / "Scripts" / "python.exe"

HOST = os.environ.get("APP_SSH_HOST", "10.10.8.83")
USER = os.environ.get("APP_SSH_USER", "root")
PASSWORD = os.environ.get("APP_SSH_PASSWORD") or os.environ.get("APP_SSH_PASS") or "P@ssw0rd@123"
LOCAL_PORT = int(os.environ.get("APP_TUNNEL_LOCAL_PORT", "55432"))


class ForwardServer(socketserver.ThreadingTCPServer):
    daemon_threads = True
    allow_reuse_address = True


def make_handler(transport: paramiko.Transport):
    class Handler(socketserver.BaseRequestHandler):
        def handle(self) -> None:
            try:
                chan = transport.open_channel(
                    "direct-tcpip",
                    ("127.0.0.1", 5432),
                    self.request.getpeername(),
                )
            except Exception:
                return
            if chan is None:
                return
            try:
                while True:
                    r, _w, _x = select.select([self.request, chan], [], [], 60)
                    if self.request in r:
                        data = self.request.recv(65536)
                        if not data:
                            break
                        chan.send(data)
                    if chan in r:
                        data = chan.recv(65536)
                        if not data:
                            break
                        self.request.send(data)
            finally:
                try:
                    chan.close()
                except Exception:
                    pass
                try:
                    self.request.close()
                except Exception:
                    pass

    return Handler


def port_open(port: int) -> bool:
    s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    s.settimeout(1)
    try:
        return s.connect_ex(("127.0.0.1", port)) == 0
    finally:
        s.close()


def log(msg: str, lines: list[str]) -> None:
    print(msg, flush=True)
    lines.append(msg)


def main() -> int:
    lines: list[str] = []
    client = paramiko.SSHClient()
    client.set_missing_host_key_policy(paramiko.AutoAddPolicy())
    client.connect(
        HOST,
        username=USER,
        password=PASSWORD,
        timeout=20,
        allow_agent=False,
        look_for_keys=False,
    )
    log("SSH_OK", lines)

    _i, o, e = client.exec_command(
        "grep -E '^APP_DB_URL=' /etc/data-asset/backend.env | sed -n '1p' | cut -d= -f2-",
        timeout=30,
    )
    app_db_url = o.read().decode().strip().strip('"').strip("'")
    m = re.search(r"://([^:]+):([^@]+)@", app_db_url)
    if not m:
        log("PARSE_FAIL", lines)
        SUMMARY.write_text("\n".join(lines), encoding="utf-8")
        return 2
    # Prefer asset_app password: if URL user is not asset_app, still try same password
    # (fleet often unifies). Also try extracting from alternate keys if present.
    db_pw = urllib.parse.unquote(m.group(2))
    url_user = m.group(1)
    log(f"URL_USER={url_user}", lines)

    # Try to get asset_app password from same env or pg if needed
    _i, o2, _e2 = client.exec_command(
        "grep -E 'asset_app|APP_DB' /etc/data-asset/backend.env | sed 's/=.*$/=***/' || true",
        timeout=15,
    )
    keys = o2.read().decode()
    log("ENV_KEYS=" + keys.replace("\n", " | ")[:300], lines)

    transport = client.get_transport()
    assert transport is not None
    transport.set_keepalive(30)
    server = None
    if not port_open(LOCAL_PORT):
        server = ForwardServer(("127.0.0.1", LOCAL_PORT), make_handler(transport))
        threading.Thread(target=server.serve_forever, daemon=True).start()
        time.sleep(0.5)
        log(f"TUNNEL_STARTED {LOCAL_PORT}", lines)
    else:
        log(f"TUNNEL_ALREADY_UP {LOCAL_PORT}", lines)

    safe = urllib.parse.quote(db_pw, safe="")
    # Use asset_app as required
    test_url = f"postgresql+psycopg://asset_app:{safe}@127.0.0.1:{LOCAL_PORT}/data_asset_test"
    # Fallback: URL user if asset_app fails
    fallback_url = f"postgresql+psycopg://{url_user}:{safe}@127.0.0.1:{LOCAL_PORT}/data_asset_test"

    eng = None
    for label, url in [("asset_app", test_url), (url_user, fallback_url)]:
        try:
            eng = create_engine(url)
            with eng.connect() as conn:
                n = conn.execute(text("SELECT count(*) FROM asset.asset_tables")).scalar()
            log(f"CONNECT_OK user={label} count={n}", lines)
            test_url = url
            break
        except Exception as ex:
            log(f"CONNECT_FAIL user={label} err={type(ex).__name__}", lines)
            eng = None
    if eng is None:
        log("NO_DB_CONNECT", lines)
        SUMMARY.write_text("\n".join(lines), encoding="utf-8")
        return 3

    os.environ["APP_TEST_DB_URL"] = test_url
    os.environ["APP_DB_URL"] = test_url
    os.environ["APP_ENV"] = "test"
    os.environ["APP_RATE_LIMIT_ENABLED"] = "false"
    os.environ.setdefault("APP_JWT_SECRET", "test-only-jwt-secret-not-for-prod")

    py = str(VENV_PY if VENV_PY.exists() else sys.executable)

    # Ensure alembic_version / auth migration
    with eng.connect() as conn:
        tables = [
            r[0]
            for r in conn.execute(
                text(
                    "SELECT table_name FROM information_schema.tables "
                    "WHERE table_schema='asset' AND ("
                    "table_name LIKE '%auth%' OR table_name='alembic_version'"
                    ") ORDER BY 1"
                )
            )
        ]
    log(f"PRE_MIGRATE authish_tables={tables}", lines)

    r_al = subprocess.run(
        [py, "-m", "alembic", "upgrade", "t6a7b8c9d0e1"],
        cwd=str(BACKEND),
        capture_output=True,
        text=True,
        env=os.environ.copy(),
        timeout=180,
    )
    al_out = ((r_al.stdout or "") + "\n" + (r_al.stderr or "")).replace(db_pw, "***")
    log(f"ALEMBIC rc={r_al.returncode}", lines)
    for line in al_out.strip().splitlines()[-20:]:
        log("  " + line, lines)

    # If alembic fails due to missing baseline, stamp then upgrade
    if r_al.returncode != 0:
        # Inspect heads / current
        for cmd in (
            ["-m", "alembic", "current"],
            ["-m", "alembic", "heads"],
            ["-m", "alembic", "history", "-r", "-5:"],
        ):
            rr = subprocess.run(
                [py, *cmd],
                cwd=str(BACKEND),
                capture_output=True,
                text=True,
                env=os.environ.copy(),
                timeout=60,
            )
            log(f"CMD {' '.join(cmd)} rc={rr.returncode} out={(rr.stdout or rr.stderr or '')[:300]}", lines)

        # Stamp to previous revision then upgrade auth if needed
        # Discover prior revision from file
        stamp = subprocess.run(
            [py, "-m", "alembic", "stamp", "s5f6a7b8c9d0"],
            cwd=str(BACKEND),
            capture_output=True,
            text=True,
            env=os.environ.copy(),
            timeout=60,
        )
        log(f"STAMP s5f6a7b8c9d0 rc={stamp.returncode}", lines)
        r_al2 = subprocess.run(
            [py, "-m", "alembic", "upgrade", "t6a7b8c9d0e1"],
            cwd=str(BACKEND),
            capture_output=True,
            text=True,
            env=os.environ.copy(),
            timeout=180,
        )
        log(f"ALEMBIC2 rc={r_al2.returncode} out={((r_al2.stdout or '') + (r_al2.stderr or ''))[-400:]}", lines)

    with eng.connect() as conn:
        n = conn.execute(text("SELECT count(*) FROM asset.asset_tables")).scalar()
        auth_tables = [
            r[0]
            for r in conn.execute(
                text(
                    "SELECT table_name FROM information_schema.tables "
                    "WHERE table_schema='asset' AND table_name LIKE '%auth%' ORDER BY 1"
                )
            )
        ]
        try:
            ver = conn.execute(text("SELECT version_num FROM alembic_version LIMIT 1")).scalar()
        except Exception as ex:
            try:
                ver = conn.execute(text("SELECT version_num FROM asset.alembic_version LIMIT 1")).scalar()
            except Exception as ex2:
                ver = f"err:{type(ex2).__name__}"
    log(f"POST count={n} auth_tables={auth_tables} alembic={ver}", lines)

    # local_auth
    log("PYTEST test_local_auth.py", lines)
    r1 = subprocess.run(
        [py, "-m", "pytest", "tests/test_local_auth.py", "-q", "--tb=line"],
        cwd=str(BACKEND),
        capture_output=True,
        text=True,
        env=os.environ.copy(),
        timeout=600,
    )
    out1 = ((r1.stdout or "") + "\n" + (r1.stderr or "")).replace(db_pw, "***")
    log(f"LOCAL_AUTH rc={r1.returncode}", lines)
    for line in out1.strip().splitlines()[-25:]:
        log("  " + line, lines)

    # full suite
    log("PYTEST tests/ full", lines)
    r2 = subprocess.run(
        [py, "-m", "pytest", "tests/", "-q", "--tb=line"],
        cwd=str(BACKEND),
        capture_output=True,
        text=True,
        env=os.environ.copy(),
        timeout=1800,
    )
    out2 = ((r2.stdout or "") + "\n" + (r2.stderr or "")).replace(db_pw, "***")
    log(f"FULL rc={r2.returncode}", lines)
    for line in out2.strip().splitlines()[-50:]:
        log("  " + line, lines)

    SUMMARY.write_text("\n".join(lines), encoding="utf-8")
    log(f"SUMMARY {SUMMARY}", lines)

    if server is not None:
        try:
            server.shutdown()
        except Exception:
            pass
    client.close()
    return 0 if r1.returncode == 0 and r2.returncode == 0 else 1


if __name__ == "__main__":
    raise SystemExit(main())
