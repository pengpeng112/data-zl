"""On 10.10.8.83: ensure data_asset_test has auth tables + privileges for asset_app.

Runs as root via SSH, SQL as postgres superuser. No secrets printed.
Optionally reclones if COUNT != 865.
"""
from __future__ import annotations

import os
import re
import select
import socket
import socketserver
import threading
import time
import urllib.parse

import paramiko
from sqlalchemy import create_engine, text

HOST = os.environ.get("APP_SSH_HOST", "10.10.8.83")
USER = os.environ.get("APP_SSH_USER", "root")
PASSWORD = os.environ.get("APP_SSH_PASSWORD") or os.environ.get("APP_SSH_PASS") or "P@ssw0rd@123"
LOCAL_PORT = int(os.environ.get("APP_TUNNEL_LOCAL_PORT", "55432"))


class ForwardServer(socketserver.ThreadingTCPServer):
    daemon_threads = True
    allow_reuse_address = True


def make_handler(transport: paramiko.Transport):
    class Handler(socketserver.BaseRequestHandler):
        def handle(self) -> None:
            try:
                chan = transport.open_channel(
                    "direct-tcpip",
                    ("127.0.0.1", 5432),
                    self.request.getpeername(),
                )
            except Exception:
                return
            if chan is None:
                return
            try:
                while True:
                    r, _w, _x = select.select([self.request, chan], [], [], 60)
                    if self.request in r:
                        data = self.request.recv(65536)
                        if not data:
                            break
                        chan.send(data)
                    if chan in r:
                        data = chan.recv(65536)
                        if not data:
                            break
                        self.request.send(data)
            finally:
                try:
                    chan.close()
                except Exception:
                    pass
                try:
                    self.request.close()
                except Exception:
                    pass

    return Handler


def port_open(port: int) -> bool:
    s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    s.settimeout(1)
    try:
        return s.connect_ex(("127.0.0.1", port)) == 0
    finally:
        s.close()


def ssh_exec(client: paramiko.SSHClient, cmd: str, timeout: int = 300) -> tuple[int, str, str]:
    _i, o, e = client.exec_command(cmd, timeout=timeout)
    out = o.read().decode("utf-8", errors="replace")
    err = e.read().decode("utf-8", errors="replace")
    return o.channel.recv_exit_status(), out, err


def main() -> int:
    client = paramiko.SSHClient()
    client.set_missing_host_key_policy(paramiko.AutoAddPolicy())
    client.connect(HOST, username=USER, password=PASSWORD, timeout=20, allow_agent=False, look_for_keys=False)
    print("SSH_OK", flush=True)

    code, out, err = ssh_exec(
        client,
        "grep -E '^APP_DB_URL=' /etc/data-asset/backend.env | sed -n '1p' | cut -d= -f2-",
        timeout=30,
    )
    app_db_url = out.strip().strip('"').strip("'")
    m = re.search(r"://([^:]+):([^@]+)@", app_db_url)
    db_pw = urllib.parse.unquote(m.group(2))

    # Full server-side prepare: reclone + auth tables + grants
    script = r'''
set -e
PSQL=/usr/local/pgsql/bin/psql
# free template: block new conns on data_asset, terminate, clone, re-allow
sudo -u postgres "$PSQL" -d postgres -v ON_ERROR_STOP=1 <<'SQL'
UPDATE pg_database SET datallowconn = false WHERE datname = 'data_asset';
SELECT pg_terminate_backend(pid) FROM pg_stat_activity
 WHERE datname IN ('data_asset_test','data_asset') AND pid <> pg_backend_pid();
DROP DATABASE IF EXISTS data_asset_test;
SQL
sleep 1
set +e
CREATE_OK=0
for i in 1 2 3 4 5 6 7 8; do
  sudo -u postgres "$PSQL" -d postgres -c "SELECT pg_terminate_backend(pid) FROM pg_stat_activity WHERE datname IN ('data_asset_test','data_asset') AND pid <> pg_backend_pid();" >/dev/null 2>&1
  if sudo -u postgres "$PSQL" -d postgres -v ON_ERROR_STOP=1 -c "CREATE DATABASE data_asset_test WITH TEMPLATE data_asset OWNER asset_app;"; then
    echo "CREATE_OK try=$i"
    CREATE_OK=1
    break
  fi
  echo "CREATE_RETRY try=$i"
  sleep 2
done
# always re-enable template DB connections
sudo -u postgres "$PSQL" -d postgres -c "UPDATE pg_database SET datallowconn = true WHERE datname = 'data_asset';" || true
set -e
if [ "$CREATE_OK" != "1" ]; then
  echo CREATE_FAIL
  exit 3
fi
sudo -u postgres "$PSQL" -d postgres -tAc "SELECT 1 FROM pg_database WHERE datname='data_asset_test'" | grep -q 1

# reown + grants + auth tables + alembic_version
sudo -u postgres "$PSQL" -d data_asset_test -v ON_ERROR_STOP=1 <<'SQL'
-- ownership for asset schema
DO $$
DECLARE r record;
BEGIN
  EXECUTE 'ALTER SCHEMA asset OWNER TO asset_app';
  FOR r IN SELECT tablename FROM pg_tables WHERE schemaname = 'asset' LOOP
    EXECUTE format('ALTER TABLE asset.%I OWNER TO asset_app', r.tablename);
  END LOOP;
  FOR r IN SELECT sequence_name FROM information_schema.sequences WHERE sequence_schema = 'asset' LOOP
    EXECUTE format('ALTER SEQUENCE asset.%I OWNER TO asset_app', r.sequence_name);
  END LOOP;
END$$;

GRANT ALL ON SCHEMA asset TO asset_app;
GRANT ALL ON ALL TABLES IN SCHEMA asset TO asset_app;
GRANT ALL ON ALL SEQUENCES IN SCHEMA asset TO asset_app;
ALTER DEFAULT PRIVILEGES IN SCHEMA asset GRANT ALL ON TABLES TO asset_app;
ALTER DEFAULT PRIVILEGES IN SCHEMA asset GRANT ALL ON SEQUENCES TO asset_app;

-- alembic_version may live in public
DO $$
BEGIN
  IF EXISTS (SELECT 1 FROM information_schema.tables WHERE table_name='alembic_version') THEN
    EXECUTE 'ALTER TABLE alembic_version OWNER TO asset_app';
    EXECUTE 'GRANT ALL ON TABLE alembic_version TO asset_app';
  ELSE
    CREATE TABLE alembic_version (version_num VARCHAR(32) NOT NULL);
    ALTER TABLE alembic_version OWNER TO asset_app;
    INSERT INTO alembic_version(version_num) VALUES ('s5f6a7b8c9d0');
  END IF;
END$$;

-- auth tables (idempotent)
CREATE TABLE IF NOT EXISTS asset.asset_auth_users (
  id BIGSERIAL PRIMARY KEY,
  username TEXT NOT NULL,
  password_hash TEXT NOT NULL,
  user_identifier TEXT,
  enabled BOOLEAN NOT NULL DEFAULT true,
  must_change_password BOOLEAN NOT NULL DEFAULT false,
  failed_login_count INTEGER NOT NULL DEFAULT 0,
  locked_until TIMESTAMPTZ,
  last_login_at TIMESTAMPTZ,
  created_at TIMESTAMPTZ DEFAULT now(),
  updated_at TIMESTAMPTZ DEFAULT now()
);
CREATE UNIQUE INDEX IF NOT EXISTS ix_asset_auth_users_username ON asset.asset_auth_users (username);
CREATE INDEX IF NOT EXISTS ix_asset_auth_users_user_identifier ON asset.asset_auth_users (user_identifier);

CREATE TABLE IF NOT EXISTS asset.asset_auth_sessions (
  id BIGSERIAL PRIMARY KEY,
  user_id BIGINT NOT NULL,
  refresh_token_hash TEXT NOT NULL,
  expires_at TIMESTAMPTZ NOT NULL,
  revoked_at TIMESTAMPTZ,
  created_at TIMESTAMPTZ DEFAULT now(),
  last_used_at TIMESTAMPTZ,
  client_ip_masked TEXT,
  user_agent TEXT
);
CREATE UNIQUE INDEX IF NOT EXISTS ix_asset_auth_sessions_refresh_token_hash ON asset.asset_auth_sessions (refresh_token_hash);
CREATE INDEX IF NOT EXISTS ix_asset_auth_sessions_user_expires ON asset.asset_auth_sessions (user_id, expires_at);
CREATE INDEX IF NOT EXISTS ix_asset_auth_sessions_user_id ON asset.asset_auth_sessions (user_id);

CREATE TABLE IF NOT EXISTS asset.asset_auth_login_events (
  id BIGSERIAL PRIMARY KEY,
  username TEXT,
  user_identifier TEXT,
  result TEXT NOT NULL,
  reason_code TEXT,
  client_ip_masked TEXT,
  created_at TIMESTAMPTZ DEFAULT now()
);
CREATE INDEX IF NOT EXISTS ix_asset_auth_login_events_created ON asset.asset_auth_login_events (created_at);
CREATE INDEX IF NOT EXISTS ix_asset_auth_login_events_username ON asset.asset_auth_login_events (username);

ALTER TABLE asset.asset_auth_users OWNER TO asset_app;
ALTER TABLE asset.asset_auth_sessions OWNER TO asset_app;
ALTER TABLE asset.asset_auth_login_events OWNER TO asset_app;
GRANT ALL ON asset.asset_auth_users TO asset_app;
GRANT ALL ON asset.asset_auth_sessions TO asset_app;
GRANT ALL ON asset.asset_auth_login_events TO asset_app;
GRANT ALL ON ALL SEQUENCES IN SCHEMA asset TO asset_app;

-- stamp head (exactly one row)
DELETE FROM alembic_version;
INSERT INTO alembic_version(version_num) VALUES ('t6a7b8c9d0e1');

SELECT count(*) AS tables FROM asset.asset_tables;
SELECT count(*) AS auth_tbl FROM information_schema.tables WHERE table_schema='asset' AND table_name LIKE 'asset_auth%';
SELECT version_num FROM alembic_version;
SQL
echo PREPARE_OK
'''
    code, out, err = ssh_exec(client, script, timeout=600)
    print(f"PREPARE_CODE={code}", flush=True)
    print("OUT_TAIL=" + out[-1500:], flush=True)
    if err.strip():
        print("ERR_TAIL=" + err[-800:], flush=True)
    if "PREPARE_OK" not in out:
        print("PREPARE_FAIL", flush=True)
        return 3

    transport = client.get_transport()
    assert transport is not None
    transport.set_keepalive(30)
    server = None
    if not port_open(LOCAL_PORT):
        server = ForwardServer(("127.0.0.1", LOCAL_PORT), make_handler(transport))
        threading.Thread(target=server.serve_forever, daemon=True).start()
        time.sleep(0.5)
        print("TUNNEL_STARTED", flush=True)
    else:
        print("TUNNEL_ALREADY_UP", flush=True)

    safe = urllib.parse.quote(db_pw, safe="")
    test_url = f"postgresql+psycopg://asset_app:{safe}@127.0.0.1:{LOCAL_PORT}/data_asset_test"
    eng = create_engine(test_url)
    with eng.connect() as conn:
        n = conn.execute(text("SELECT count(*) FROM asset.asset_tables")).scalar()
        auth_n = conn.execute(
            text(
                "SELECT count(*) FROM information_schema.tables "
                "WHERE table_schema='asset' AND table_name LIKE 'asset_auth%'"
            )
        ).scalar()
        ver = conn.execute(text("SELECT version_num FROM alembic_version LIMIT 1")).scalar()
        # write test as asset_app
        conn.execute(text("SELECT 1 FROM asset.asset_auth_users LIMIT 1"))
        conn.commit()
    print(f"COUNT={n} AUTH={auth_n} ALEMBIC={ver}", flush=True)

    env_path = os.path.join(os.path.dirname(__file__), "_m1m2_test_env.ps1")
    with open(env_path, "w", encoding="utf-8") as f:
        f.write(f'$env:APP_TEST_DB_URL = "{test_url}"\n')
        f.write('$env:APP_ENV = "test"\n')
        f.write('$env:APP_RATE_LIMIT_ENABLED = "false"\n')
        f.write('$env:APP_JWT_SECRET = "test-only-jwt-secret-not-for-prod"\n')
    print(f"ENV_SCRIPT={env_path}", flush=True)
    print("READY", flush=True)

    # Keep tunnel if we started it
    if server is not None:
        print("KEEPING_TUNNEL", flush=True)
        try:
            while True:
                time.sleep(3600)
        except KeyboardInterrupt:
            server.shutdown()
    client.close()
    return 0 if n == 865 and auth_n >= 3 else 4


if __name__ == "__main__":
    raise SystemExit(main())
