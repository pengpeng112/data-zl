"""Reclone data_asset_test from data_asset on 10.10.8.83 and verify counts.

No secrets printed. Uses APP_SSH_PASSWORD env or hospital internal pattern.
"""
from __future__ import annotations

import os
import re
import select
import socket
import socketserver
import threading
import time
import urllib.parse

import paramiko
from sqlalchemy import create_engine, text

HOST = os.environ.get("APP_SSH_HOST", "10.10.8.83")
USER = os.environ.get("APP_SSH_USER", "root")
PASSWORD = os.environ.get("APP_SSH_PASSWORD") or os.environ.get("APP_SSH_PASS") or "P@ssw0rd@123"
LOCAL_PORT = int(os.environ.get("APP_TUNNEL_LOCAL_PORT", "55432"))


class ForwardServer(socketserver.ThreadingTCPServer):
    daemon_threads = True
    allow_reuse_address = True


def make_handler(transport: paramiko.Transport):
    class Handler(socketserver.BaseRequestHandler):
        def handle(self) -> None:
            try:
                chan = transport.open_channel(
                    "direct-tcpip",
                    ("127.0.0.1", 5432),
                    self.request.getpeername(),
                )
            except Exception:
                return
            if chan is None:
                return
            try:
                while True:
                    r, _w, _x = select.select([self.request, chan], [], [], 60)
                    if self.request in r:
                        data = self.request.recv(65536)
                        if not data:
                            break
                        chan.send(data)
                    if chan in r:
                        data = chan.recv(65536)
                        if not data:
                            break
                        self.request.send(data)
            finally:
                try:
                    chan.close()
                except Exception:
                    pass
                try:
                    self.request.close()
                except Exception:
                    pass

    return Handler


def port_open(port: int) -> bool:
    s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    s.settimeout(1)
    try:
        return s.connect_ex(("127.0.0.1", port)) == 0
    finally:
        s.close()


def ssh_exec(client: paramiko.SSHClient, cmd: str, timeout: int = 300) -> tuple[int, str, str]:
    _stdin, stdout, stderr = client.exec_command(cmd, timeout=timeout)
    out = stdout.read().decode("utf-8", errors="replace")
    err = stderr.read().decode("utf-8", errors="replace")
    code = stdout.channel.recv_exit_status()
    return code, out, err


def main() -> int:
    client = paramiko.SSHClient()
    client.set_missing_host_key_policy(paramiko.AutoAddPolicy())
    client.connect(
        HOST,
        username=USER,
        password=PASSWORD,
        timeout=20,
        allow_agent=False,
        look_for_keys=False,
    )
    print("SSH_OK", flush=True)

    code, out, err = ssh_exec(
        client,
        "grep -E '^APP_DB_URL=' /etc/data-asset/backend.env | sed -n '1p' | cut -d= -f2-",
        timeout=30,
    )
    if code != 0 or not out.strip():
        print("ENV_FAIL", flush=True)
        return 2
    app_db_url = out.strip().strip('"').strip("'")
    m = re.search(r"://([^:]+):([^@]+)@", app_db_url)
    if not m:
        print("PARSE_FAIL", flush=True)
        return 2
    db_user = m.group(1)
    db_pw = urllib.parse.unquote(m.group(2))
    print(f"DB_USER={db_user}", flush=True)

    script = r"""
set -e
PSQL=""
for c in /usr/local/pgsql/bin/psql /usr/bin/psql; do
  if [ -x "$c" ]; then PSQL=$c; break; fi
done
if [ -z "$PSQL" ]; then PSQL=$(command -v psql); fi
echo "PSQL=$PSQL"
# Terminate sessions on both template and target
sudo -u postgres "$PSQL" -d postgres -v ON_ERROR_STOP=1 -c "SELECT pg_terminate_backend(pid) FROM pg_stat_activity WHERE datname IN ('data_asset_test','data_asset') AND pid <> pg_backend_pid();"
sudo -u postgres "$PSQL" -d postgres -v ON_ERROR_STOP=1 -c "DROP DATABASE IF EXISTS data_asset_test;"
# Brief pause so template is free
sleep 1
sudo -u postgres "$PSQL" -d postgres -v ON_ERROR_STOP=1 -c "CREATE DATABASE data_asset_test WITH TEMPLATE data_asset OWNER asset_app;"
sudo -u postgres "$PSQL" -d data_asset_test -v ON_ERROR_STOP=1 <<'SQL'
DO $$
DECLARE r record;
BEGIN
  EXECUTE 'ALTER SCHEMA asset OWNER TO asset_app';
  FOR r IN SELECT tablename FROM pg_tables WHERE schemaname = 'asset' LOOP
    EXECUTE format('ALTER TABLE asset.%I OWNER TO asset_app', r.tablename);
  END LOOP;
  FOR r IN SELECT sequence_name FROM information_schema.sequences WHERE sequence_schema = 'asset' LOOP
    EXECUTE format('ALTER SEQUENCE asset.%I OWNER TO asset_app', r.sequence_name);
  END LOOP;
END$$;
GRANT ALL ON SCHEMA asset TO asset_app;
GRANT ALL ON ALL TABLES IN SCHEMA asset TO asset_app;
GRANT ALL ON ALL SEQUENCES IN SCHEMA asset TO asset_app;
SQL
echo RECLONE_OK
"""
    code, out, err = ssh_exec(client, script, timeout=600)
    print(f"RECLONE_CODE={code}", flush=True)
    print("RECLONE_OUT_TAIL=" + out[-1000:].replace(db_pw, "***"), flush=True)
    if err.strip():
        print("RECLONE_ERR_TAIL=" + err[-1000:].replace(db_pw, "***"), flush=True)
    if "RECLONE_OK" not in out:
        print("RECLONE_FAIL", flush=True)
        return 3

    transport = client.get_transport()
    assert transport is not None
    transport.set_keepalive(30)
    server = None
    if not port_open(LOCAL_PORT):
        server = ForwardServer(("127.0.0.1", LOCAL_PORT), make_handler(transport))
        threading.Thread(target=server.serve_forever, daemon=True).start()
        time.sleep(0.5)
        print(f"TUNNEL_STARTED port={LOCAL_PORT}", flush=True)
    else:
        print(f"TUNNEL_ALREADY_UP port={LOCAL_PORT}", flush=True)

    safe = urllib.parse.quote(db_pw, safe="")
    test_url = f"postgresql+psycopg://asset_app:{safe}@127.0.0.1:{LOCAL_PORT}/data_asset_test"
    eng = create_engine(test_url)
    with eng.connect() as conn:
        n = conn.execute(text("SELECT count(*) FROM asset.asset_tables")).scalar()
        auth_n = conn.execute(
            text(
                "SELECT count(*) FROM information_schema.tables "
                "WHERE table_schema='asset' AND table_name LIKE 'asset_auth%'"
            )
        ).scalar()
        try:
            ver = conn.execute(text("SELECT version_num FROM alembic_version LIMIT 1")).scalar()
        except Exception as e:
            ver = f"err:{type(e).__name__}"
    print(f"COUNT={n}", flush=True)
    print(f"AUTH_TABLES={auth_n}", flush=True)
    print(f"ALEMBIC={ver}", flush=True)

    # Write env helper for subsequent pytest (local file, gitignored ideally)
    env_path = os.path.join(os.path.dirname(__file__), "_m1m2_test_env.ps1")
    # Still write password into session script for local pytest only; do not commit.
    with open(env_path, "w", encoding="utf-8") as f:
        f.write(f'$env:APP_TEST_DB_URL = "{test_url}"\n')
        f.write('$env:APP_ENV = "test"\n')
        f.write('$env:APP_RATE_LIMIT_ENABLED = "false"\n')
        f.write('$env:APP_JWT_SECRET = "test-only-jwt-secret-not-for-prod"\n')
    print(f"ENV_SCRIPT={env_path}", flush=True)
    print("READY", flush=True)

    if server is not None:
        # keep process alive if we own the tunnel
        print("KEEPING_TUNNEL", flush=True)
        try:
            while True:
                time.sleep(3600)
        except KeyboardInterrupt:
            server.shutdown()
            client.close()
    else:
        client.close()
    return 0 if n == 865 else 4


if __name__ == "__main__":
    raise SystemExit(main())
