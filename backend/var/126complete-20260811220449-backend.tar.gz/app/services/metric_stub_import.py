"""Register unavailable placeholder metrics for core institution numbers without SQL."""
from __future__ import annotations

from sqlalchemy.orm import Session

from .metric_service import get_metric, ingest_metric

# Known missing slots vs 1..48 that have no SQL in the repo (as of 2026-08-11).
# Titles use neutral placeholders; replace when SQL becomes available.
MISSING_CORE_METRICS: dict[int, str] = {
    1: "（待补录）核心制度指标01",
    2: "（待补录）核心制度指标02",
    11: "（待补录）核心制度指标11",
    12: "（待补录）核心制度指标12",
    13: "（待补录）核心制度指标13",
    14: "（待补录）核心制度指标14",
    15: "（待补录）核心制度指标15",
    22: "（待补录）核心制度指标22",
    29: "（待补录）核心制度指标29",
    30: "（待补录）核心制度指标30",
    33: "（待补录）核心制度指标33",
    34: "（待补录）核心制度指标34",
    35: "（待补录）核心制度指标35",
    36: "（待补录）核心制度指标36",
    37: "（待补录）核心制度指标37",
    38: "（待补录）核心制度指标38",
    39: "（待补录）核心制度指标39",
    40: "（待补录）核心制度指标40",
    46: "（待补录）核心制度指标46",
    47: "（待补录）核心制度指标47",
    48: "（待补录）核心制度指标48",
}


def import_missing_metric_stubs(
    db: Session,
    *,
    dry_run: bool = True,
    created_by: str = "metric_stub_import",
) -> dict:
    items = []
    for num, title in sorted(MISSING_CORE_METRICS.items()):
        code = f"MET_CORE_{num:02d}"
        if get_metric(db, code):
            items.append({"metric_code": code, "status": "exists", "title": title})
            continue
        if dry_run:
            items.append({"metric_code": code, "status": "would_create", "title": title})
            continue
        # force blocked/unavailable: no query, only definition text
        r = ingest_metric(
            db,
            metric_code=code,
            title=title,
            meaning="仓库无可用 SQL，登记为待补录占位，禁止作为现行可执行指标。",
            category="48项核心制度",
            definition_text="无 SQL 源文件；状态 candidate/blocked，待业务补录后修订。",
            formula=None,
            query_code=None,
            limitations=["无可用SQL", "不可提取", "占位登记"],
            created_by=created_by,
            auto_activate=False,
        )
        # ensure not active
        items.append(
            {
                "metric_code": code,
                "status": r["version"]["status"],
                "is_active": r["version"]["is_active"],
                "title": title,
            }
        )
    if not dry_run:
        db.commit()
    return {"dry_run": dry_run, "count": len(items), "items": items}
