"""Post-deploy finish: stubs, CSV results, publish data products."""
from pathlib import Path

from app.core.db import SessionLocal
from app.services.data_product_service import publish_core_products
from app.services.metric_result_import import import_all_result_csvs
from app.services.metric_stub_import import import_missing_metric_stubs

# Prefer /app/取数 (docker cp) then monorepo roots.
REPO_CANDIDATES = [Path("/app"), Path("/opt/data-asset"), Path(__file__).resolve().parents[2]]

db = SessionLocal()
try:
    stubs = import_missing_metric_stubs(db, dry_run=False, created_by="finish_126")
    print("stubs", stubs["count"], "sample", stubs["items"][:3])
except Exception as exc:
    db.rollback()
    print("stubs_err", type(exc).__name__, exc)

try:
    root = next((p for p in REPO_CANDIDATES if (p / "取数").is_dir()), Path("/app"))
    res = import_all_result_csvs(db, dry_run=False, created_by="finish_126", repo_root=root)
    print("results", {"repo_root": str(root), **{k: res[k] for k in ("file_count", "total_inserted", "dry_run")}})
    for it in res.get("items") or []:
        print("  csv", Path(it["csv"]).name, "inserted", it["inserted"], "skipped", it["skipped"])
except Exception as exc:
    db.rollback()
    print("results_err", type(exc).__name__, exc)

try:
    pub = publish_core_products(db, created_by="finish_126")
    db.commit()
    print("products", pub["count"])
except Exception as exc:
    db.rollback()
    print("products_err", type(exc).__name__, exc)
finally:
    db.close()
