/* ============================================================
   指标 16：非计划再次手术疑难病例讨论率 （保留WITH：查询较复杂）
   ------------------------------------------------------------
   docx 口径依据：
  分子：非计划再次手术患者完成疑难讨论结论记录的数量
   分母：同期非计划再次手术总次数
   候选：OPERATION_MASTER无非计划标志，用同住院手术≥2近似
   统计期：2026-01-01 ~ 2026-08-01（左闭右开，1-7月）
   月份归属：按 HIS.PAT_VISIT.DISCHARGE_DATE_TIME
   输出：指标 | 月份 | 分子 | 分母 | 说明
   ============================================================ */
WITH multi_op AS (
    SELECT v.patient_id, v.visit_id, TO_CHAR(v.discharge_date_time,'YYYY-MM') AS 月份
    FROM HIS.PAT_VISIT v
    JOIN HIS.OPERATION_MASTER o ON o.patient_id=v.patient_id AND o.visit_id=v.visit_id
    WHERE v.discharge_date_time >= TO_DATE('2026-01-01 00:00:00','YYYY-MM-DD HH24:MI:SS') AND v.discharge_date_time < TO_DATE('2026-08-01 00:00:00','YYYY-MM-DD HH24:MI:SS')
    GROUP BY v.patient_id, v.visit_id, v.discharge_date_time HAVING COUNT(*) >= 2
),
disc_doc AS (
    SELECT m.patient_id, m.visit_id,
        MAX(CASE WHEN INSTR(NVL(f.topic,' '),'疑难')>0 AND INSTR(NVL(f.topic,' '),'讨论')>0 THEN 1 ELSE 0 END) AS done
    FROM multi_op m
    JOIN JHEMR.JHMR_FILE_INDEX f ON f.patient_id=m.patient_id AND f.visit_id=m.visit_id
    WHERE NVL(f.delete_flag,0)=0
    GROUP BY m.patient_id, m.visit_id
)
SELECT '指标 16：非计划再次手术疑难病例讨论率' AS 指标, m.月份, SUM(NVL(d.done,0)) AS 分子, COUNT(*) AS 分母,
    '候选-同住院手术≥2待科室确认非计划' AS 说明
FROM multi_op m LEFT JOIN disc_doc d ON d.patient_id=m.patient_id AND d.visit_id=m.visit_id
GROUP BY m.月份
ORDER BY 月份
