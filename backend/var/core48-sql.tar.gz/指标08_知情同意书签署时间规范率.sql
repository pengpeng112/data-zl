/* ============================================================
   指标 8：手术知情同意书签署时间规范率 （保留WITH：查询较复杂）
   ------------------------------------------------------------
   docx 口径依据：
  分子：术前讨论后签署同意书的数量（术前讨论签名时间<同意书签名时间）
   分母：同期签署手术同意书的数量
   纳排：纳入住院手术；排除纸质、紧急救治生命手术
   统计期：2026-01-01 ~ 2026-08-01（左闭右开，1-7月）
   月份归属：按 HIS.PAT_VISIT.DISCHARGE_DATE_TIME
   输出：指标 | 月份 | 分子 | 分母 | 说明
   ============================================================ */
WITH ops AS (
    SELECT o.patient_id, o.visit_id, o.oper_id, o.start_date_time,
           TO_CHAR(v.discharge_date_time,'YYYY-MM') AS 月份
    FROM HIS.OPERATION_MASTER o
    JOIN HIS.PAT_VISIT v ON v.patient_id=o.patient_id AND v.visit_id=o.visit_id
    WHERE v.discharge_date_time >= TO_DATE('2026-01-01 00:00:00','YYYY-MM-DD HH24:MI:SS') AND v.discharge_date_time < TO_DATE('2026-08-01 00:00:00','YYYY-MM-DD HH24:MI:SS') AND o.start_date_time IS NOT NULL AND NVL(o.emergency_indicator,0)<>1
),
sign_times AS (
    SELECT o.月份, o.patient_id, o.visit_id, o.oper_id,
        MIN(CASE WHEN f.mr_class='EMR07.00.01' AND f.first_mr_sign_date_time < o.start_date_time
                 THEN f.first_mr_sign_date_time END) AS consent_time,
        MIN(CASE WHEN f.mr_class='EMR10.00.10'
                  AND INSTR(NVL(f.topic,f.file_name),'术前讨论')>0
                  AND f.first_mr_sign_date_time < o.start_date_time
                 THEN f.first_mr_sign_date_time END) AS discussion_time
    FROM ops o
    JOIN JHEMR.JHMR_FILE_INDEX f ON f.patient_id=o.patient_id AND f.visit_id=o.visit_id
    WHERE NVL(f.delete_flag,0)=0 AND f.first_mr_sign_date_time IS NOT NULL
    GROUP BY o.月份, o.patient_id, o.visit_id, o.oper_id, o.start_date_time
)
SELECT '指标 8：手术知情同意书签署时间规范率' AS 指标, o.月份,
    COUNT(DISTINCT CASE WHEN s.discussion_time < s.consent_time
                        THEN o.patient_id||'|'||o.visit_id||'|'||o.oper_id END) AS 分子,
    COUNT(DISTINCT CASE WHEN s.consent_time IS NOT NULL
                        THEN o.patient_id||'|'||o.visit_id||'|'||o.oper_id END) AS 分母,
    '有限可用' AS 说明
FROM ops o LEFT JOIN sign_times s ON s.patient_id=o.patient_id AND s.visit_id=o.visit_id AND s.oper_id=o.oper_id
GROUP BY o.月份
ORDER BY 月份
