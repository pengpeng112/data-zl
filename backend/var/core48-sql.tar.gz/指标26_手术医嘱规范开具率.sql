/* ============================================================
   指标 26：手术医嘱规范开具率 （保留WITH：多级时间聚合）
   ------------------------------------------------------------
   docx 口径依据：
  分子：手术医嘱在术前讨论完成及签署手术知情同意书后开具的次数
   分母：同期住院患者手术次数
   纳排：纳入有手术；排除紧急救治生命的手术
   数据来源：术前讨论记录创建/书写时间，签署手术知情同意书的时间，手术医嘱开具时间
   ------------------------------------------------------------
   实现说明：
   手术医嘱开具时间 = SM.MED_OPERATION_SCHEDULE.REQ_DATE_TIME（手术申请表）
   术前讨论完成时间 = JHMR_FILE_INDEX EMR10.00.10（含"术前讨论"）签名时间
   知情同意签署时间 = JHMR_FILE_INDEX EMR07.00.01 签名时间
   分子：申请时间存在 + 术前讨论签名存在 + 知情同意签名存在
         + 申请时间 >= 术前讨论签名 + 申请时间 >= 知情同意签名
   分母：SM.MED_OPERATION_MASTER 住院手术台次（非急诊、有效）
   注：SCHEDULE 与 MASTER 的 OPER_ID 匹配率约 58%，未匹配的申请时间为空不计分子
   统计期：2026-01-01 ~ 2026-08-01（左闭右开，1-7月）
   月份归属：按 HIS.PAT_VISIT.DISCHARGE_DATE_TIME
   输出：指标 | 月份 | 分子 | 分母 | 说明
   ============================================================ */
WITH ops AS (
    SELECT m.patient_id, m.visit_id, m.oper_id,
           TO_CHAR(v.discharge_date_time,'YYYY-MM') AS 月份
    FROM SM.MED_OPERATION_MASTER m
    JOIN HIS.PAT_VISIT v ON v.patient_id=m.patient_id AND v.visit_id=m.visit_id
    WHERE v.discharge_date_time >= TO_DATE('2026-01-01 00:00:00','YYYY-MM-DD HH24:MI:SS')
      AND v.discharge_date_time <  TO_DATE('2026-08-01 00:00:00','YYYY-MM-DD HH24:MI:SS')
      AND m.visit_id > 0
      AND m.start_date_time IS NOT NULL AND m.end_date_time IS NOT NULL
      AND m.end_date_time > m.start_date_time
      AND m.oper_status >= 35
      AND m.cancel_date_time IS NULL
      AND NVL(m.emergency_indicator,0) <> 1
),
sch AS (
    SELECT patient_id, visit_id, oper_id, MIN(req_date_time) AS req_time
    FROM SM.MED_OPERATION_SCHEDULE
    WHERE state <> -1 AND req_date_time IS NOT NULL
    GROUP BY patient_id, visit_id, oper_id
),
doc_times AS (
    SELECT o.patient_id, o.visit_id,
        MIN(CASE WHEN f.mr_class = 'EMR10.00.10'
                  AND INSTR(NVL(f.topic,f.file_name),'术前讨论') > 0
                 THEN f.first_mr_sign_date_time END) AS disc_time,
        MIN(CASE WHEN f.mr_class = 'EMR07.00.01'
                 THEN f.first_mr_sign_date_time END) AS consent_time
    FROM ops o
    LEFT JOIN JHEMR.JHMR_FILE_INDEX f
      ON f.patient_id=o.patient_id AND f.visit_id=o.visit_id
     AND NVL(f.delete_flag,0)=0 AND f.first_mr_sign_date_time IS NOT NULL
    GROUP BY o.patient_id, o.visit_id
)
SELECT '指标 26：手术医嘱规范开具率' AS 指标,
    o.月份,
    COUNT(DISTINCT CASE WHEN s.req_time IS NOT NULL
                         AND d.disc_time IS NOT NULL
                         AND d.consent_time IS NOT NULL
                         AND s.req_time >= d.disc_time
                         AND s.req_time >= d.consent_time
                        THEN o.patient_id||'|'||o.visit_id||'|'||o.oper_id END) AS 分子,
    COUNT(DISTINCT o.patient_id||'|'||o.visit_id||'|'||o.oper_id) AS 分母,
    '可用-手术申请时间SM.MED_OPERATION_SCHEDULE.REQ_DATE_TIME' AS 说明
FROM ops o
LEFT JOIN sch s ON s.patient_id=o.patient_id AND s.visit_id=o.visit_id AND s.oper_id=o.oper_id
LEFT JOIN doc_times d ON d.patient_id=o.patient_id AND d.visit_id=o.visit_id
GROUP BY o.月份
ORDER BY 月份
