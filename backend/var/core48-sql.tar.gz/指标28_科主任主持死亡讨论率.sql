/* ============================================================
   指标 28：科主任主持死亡病例讨论率 （纯SELECT）
   ------------------------------------------------------------
   docx 口径依据：
  分子：死亡讨论由科主任主持的病例数（主持人在正文）
   分母：同期住院死亡患者病例总数
   统计期：2026-01-01 ~ 2026-08-01（左闭右开，1-7月）
   月份归属：按 HIS.PAT_VISIT.DISCHARGE_DATE_TIME
   输出：指标 | 月份 | 分子 | 分母 | 说明
   ============================================================ */
SELECT '指标 28：科主任主持死亡病例讨论率' AS 指标,
    TO_CHAR(v.discharge_date_time,'YYYY-MM') AS 月份,
    CAST(NULL AS NUMBER) AS 分子,
    COUNT(*) AS 分母,
    '仅分母-主持人位于正文索引无法证明科主任' AS 说明
FROM HIS.PAT_VISIT v
WHERE v.discharge_date_time >= TO_DATE('2026-01-01 00:00:00','YYYY-MM-DD HH24:MI:SS') AND v.discharge_date_time < TO_DATE('2026-08-01 00:00:00','YYYY-MM-DD HH24:MI:SS') AND v.discharge_disposition = '5'
GROUP BY TO_CHAR(v.discharge_date_time,'YYYY-MM')
ORDER BY 月份
