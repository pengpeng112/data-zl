/* ============================================================
   指标 24：术者术前讨论参与率 （纯SELECT）
   ------------------------------------------------------------
   docx 口径依据：
  分子：术者参与术前讨论次数（缺全部参与人员列表）
   分母：同期住院患者手术次数
   纳排：纳入有手术；排除紧急救治生命手术
   统计期：2026-01-01 ~ 2026-08-01（左闭右开，1-7月）
   月份归属：按 HIS.PAT_VISIT.DISCHARGE_DATE_TIME
   输出：指标 | 月份 | 分子 | 分母 | 说明
   ============================================================ */
SELECT '指标 24：术者术前讨论参与率' AS 指标,
    TO_CHAR(v.discharge_date_time,'YYYY-MM') AS 月份,
    CAST(NULL AS NUMBER) AS 分子,
    COUNT(DISTINCT o.patient_id||'|'||o.visit_id||'|'||o.oper_id) AS 分母,
    '仅分母-缺术前讨论全部参与人员列表' AS 说明
FROM HIS.OPERATION_MASTER o JOIN HIS.PAT_VISIT v ON v.patient_id=o.patient_id AND v.visit_id=o.visit_id
WHERE v.discharge_date_time >= TO_DATE('2026-01-01 00:00:00','YYYY-MM-DD HH24:MI:SS') AND v.discharge_date_time < TO_DATE('2026-08-01 00:00:00','YYYY-MM-DD HH24:MI:SS') AND o.start_date_time IS NOT NULL AND NVL(o.emergency_indicator,0)<>1
GROUP BY TO_CHAR(v.discharge_date_time,'YYYY-MM')
ORDER BY 月份
