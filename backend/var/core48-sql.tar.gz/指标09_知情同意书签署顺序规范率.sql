/* ============================================================
   指标 9：手术知情同意书签署顺序规范率 （纯SELECT）
   ------------------------------------------------------------
   docx 口径依据：
  分子：医师签署时间早于患方签署时间的数量（无两个独立签署时间字段）
   分母：同期签署手术知情同意书的数量
   统计期：2026-01-01 ~ 2026-08-01（左闭右开，1-7月）
   月份归属：按 HIS.PAT_VISIT.DISCHARGE_DATE_TIME
   输出：指标 | 月份 | 分子 | 分母 | 说明
   ============================================================ */
SELECT '指标 9：手术知情同意书签署顺序规范率' AS 指标,
    TO_CHAR(v.discharge_date_time,'YYYY-MM') AS 月份,
    CAST(NULL AS NUMBER) AS 分子,
    COUNT(*) AS 分母,
    '仅分母-无医师/患方独立签署时间' AS 说明
FROM HIS.PAT_VISIT v
JOIN HIS.OPERATION_MASTER o ON o.patient_id=v.patient_id AND o.visit_id=v.visit_id
JOIN JHEMR.JHMR_FILE_INDEX f ON f.patient_id=v.patient_id AND f.visit_id=v.visit_id
WHERE v.discharge_date_time >= TO_DATE('2026-01-01 00:00:00','YYYY-MM-DD HH24:MI:SS') AND v.discharge_date_time < TO_DATE('2026-08-01 00:00:00','YYYY-MM-DD HH24:MI:SS') AND o.start_date_time IS NOT NULL
  AND NVL(f.delete_flag,0)=0 AND f.mr_class='EMR07.00.01'
  AND f.first_mr_sign_date_time IS NOT NULL AND f.first_mr_sign_date_time < o.start_date_time
GROUP BY TO_CHAR(v.discharge_date_time,'YYYY-MM')
ORDER BY 月份
