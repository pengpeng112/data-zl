/* ============================================================
   指标 25：四级手术术前多学科讨论率 （纯SELECT）
   ------------------------------------------------------------
   docx 口径依据：
  分子：四级手术台次中术前完成多学科讨论的台次数
   分母：同期住院四级手术台次数
   四级判定：OPERATION_DICT.OPERATION_SCALE='四'
   多学科：含'多学科'医嘱 或 标题含'多学科'文书（术前）
   统计期：2026-01-01 ~ 2026-08-01（左闭右开，1-7月）
   月份归属：按 HIS.PAT_VISIT.DISCHARGE_DATE_TIME
   输出：指标 | 月份 | 分子 | 分母 | 说明
   ============================================================ */
SELECT '指标 25：四级手术术前多学科讨论率' AS 指标,
    TO_CHAR(v.discharge_date_time,'YYYY-MM') AS 月份,
    COUNT(DISTINCT CASE WHEN f.first_mr_sign_date_time < op.operating_date
                         AND INSTR(NVL(f.topic,f.file_name),'多学科')>0
                        THEN op.patient_id||'|'||op.visit_id||'|'||op.oper_id END) AS 分子,
    COUNT(DISTINCT op.patient_id||'|'||op.visit_id||'|'||op.oper_id) AS 分母,
    '可用-仅多学科文书口径(医嘱口径见WITH版)' AS 说明
FROM HIS.OPERATION op
JOIN HIS.OPERATION_DICT od ON od.operation_code=op.operation_code
JOIN HIS.PAT_VISIT v ON v.patient_id=op.patient_id AND v.visit_id=op.visit_id
LEFT JOIN JHEMR.JHMR_FILE_INDEX f
  ON f.patient_id=op.patient_id AND f.visit_id=op.visit_id
 AND NVL(f.delete_flag,0)=0 AND f.first_mr_sign_date_time IS NOT NULL
WHERE od.operation_scale='四' AND op.operating_date IS NOT NULL AND v.discharge_date_time >= TO_DATE('2026-01-01 00:00:00','YYYY-MM-DD HH24:MI:SS') AND v.discharge_date_time < TO_DATE('2026-08-01 00:00:00','YYYY-MM-DD HH24:MI:SS')
GROUP BY TO_CHAR(v.discharge_date_time,'YYYY-MM')
ORDER BY 月份
