/* ============================================================
   指标 4：二级医师查房频次达标率 （保留WITH：查询较复杂）
   ------------------------------------------------------------
   docx 口径依据：
  分子：每患者每周期二级医师查房次数总和（每周期封顶3次）
   分母：每患者每周期应查房次数（3次）总和
   统计期：2026-01-01 ~ 2026-08-01（左闭右开，1-7月）
   月份归属：按 HIS.PAT_VISIT.DISCHARGE_DATE_TIME
   输出：指标 | 月份 | 分子 | 分母 | 说明
   ============================================================ */
WITH visits AS (
    SELECT patient_id, visit_id, admission_date_time, discharge_date_time,
           TO_CHAR(discharge_date_time,'YYYY-MM') AS 月份
    FROM HIS.PAT_VISIT v WHERE v.discharge_date_time >= TO_DATE('2026-01-01 00:00:00','YYYY-MM-DD HH24:MI:SS') AND v.discharge_date_time < TO_DATE('2026-08-01 00:00:00','YYYY-MM-DD HH24:MI:SS') AND v.discharge_date_time - v.admission_date_time > 1
),
cycles AS (
    SELECT v.月份, v.patient_id, v.visit_id, v.admission_date_time, v.discharge_date_time, n.cycle_no
    FROM visits v
    CROSS JOIN (SELECT LEVEL AS cycle_no FROM dual CONNECT BY LEVEL <= 100) n
    WHERE n.cycle_no <= CEIL((v.discharge_date_time - v.admission_date_time)/7)
),
round_cnt AS (
    SELECT c.月份, SUM(CASE WHEN f.mr_class='EMR10.00.03'
        AND (INSTR(NVL(f.topic_title_name,' '),'主治')>0
          OR INSTR(NVL(f.topic,f.file_name),'主治医师查房')>0) THEN 1 ELSE 0 END) AS lvl2_cnt
    FROM cycles c
    LEFT JOIN JHEMR.JHMR_FILE_INDEX f ON f.patient_id=c.patient_id AND f.visit_id=c.visit_id
      AND NVL(f.delete_flag,0)=0 AND f.first_mr_sign_date_time IS NOT NULL
      AND f.first_mr_sign_date_time >= c.admission_date_time + (c.cycle_no-1)*7
      AND f.first_mr_sign_date_time <  LEAST(c.admission_date_time + c.cycle_no*7, c.discharge_date_time)
    GROUP BY c.月份, c.patient_id, c.visit_id, c.cycle_no
)
SELECT '指标 4：二级医师查房频次达标率' AS 指标, 月份, SUM(LEAST(lvl2_cnt,3)) AS 分子, COUNT(*)*3 AS 分母,
    '有限可用-依赖标题职称字样' AS 说明
FROM round_cnt GROUP BY 月份
ORDER BY 月份
