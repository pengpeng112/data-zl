/* ============================================================
   指标 21：抢救记录审核率 （纯SELECT）
   ------------------------------------------------------------
   docx 口径依据：
  分子：有主持抢救医师审核签字的抢救记录数量（签名不能证明主持审核）
   分母：同期抢救记录总数（EMR10.00.08）
   统计期：2026-01-01 ~ 2026-08-01（左闭右开，1-7月）
   月份归属：按 HIS.PAT_VISIT.DISCHARGE_DATE_TIME
   输出：指标 | 月份 | 分子 | 分母 | 说明
   ============================================================ */
SELECT '指标 21：抢救记录审核率' AS 指标,
    TO_CHAR(v.discharge_date_time,'YYYY-MM') AS 月份,
    CAST(NULL AS NUMBER) AS 分子,
    COUNT(*) AS 分母,
    '仅分母-签名不能证明主持医师审核' AS 说明
FROM HIS.PAT_VISIT v
JOIN JHEMR.JHMR_FILE_INDEX f ON f.patient_id=v.patient_id AND f.visit_id=v.visit_id
WHERE v.discharge_date_time >= TO_DATE('2026-01-01 00:00:00','YYYY-MM-DD HH24:MI:SS') AND v.discharge_date_time < TO_DATE('2026-08-01 00:00:00','YYYY-MM-DD HH24:MI:SS') AND NVL(f.delete_flag,0)=0 AND f.first_mr_sign_date_time IS NOT NULL
  AND f.mr_class = 'EMR10.00.08'
GROUP BY TO_CHAR(v.discharge_date_time,'YYYY-MM')
ORDER BY 月份
