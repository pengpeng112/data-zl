/* ============================================================
   指标 20：抢救记录及时完成率 （保留WITH：查询较复杂）
   ------------------------------------------------------------
   docx 口径依据：
  ★用户确认口径(大抢救成功率，非docx原6h完成率)
   分母：大抢救医嘱事件数(含'大抢救'或'院内抢救费'，去重P+V+START)
   分子：上述事件中开立后24h内未开死亡医嘱(=成功)
   统计期：2026-01-01 ~ 2026-08-01（左闭右开，1-7月）
   月份归属：按 HIS.PAT_VISIT.DISCHARGE_DATE_TIME
   输出：指标 | 月份 | 分子 | 分母 | 说明
   ============================================================ */
WITH rescue_evt AS (
    SELECT DISTINCT o.patient_id, o.visit_id, o.start_date_time, v.discharge_date_time
    FROM HIS.ORDERS o
    JOIN HIS.PAT_VISIT v ON v.patient_id=o.patient_id AND v.visit_id=o.visit_id
    WHERE o.cancel_date_time IS NULL AND o.start_date_time IS NOT NULL
      AND (INSTR(o.order_text,'大抢救')>0 OR INSTR(o.order_text,'院内抢救费')>0)
      AND o.start_date_time >= TO_DATE('2026-01-01 00:00:00','YYYY-MM-DD HH24:MI:SS') - 90 AND o.start_date_time < TO_DATE('2026-08-01 00:00:00','YYYY-MM-DD HH24:MI:SS') AND v.discharge_date_time >= TO_DATE('2026-01-01 00:00:00','YYYY-MM-DD HH24:MI:SS') AND v.discharge_date_time < TO_DATE('2026-08-01 00:00:00','YYYY-MM-DD HH24:MI:SS')
),
death_flag AS (
    SELECT r.patient_id, r.visit_id, r.start_date_time,
        MAX(CASE WHEN d.start_date_time >= r.start_date_time AND d.start_date_time < r.start_date_time + 1
                 THEN 1 ELSE 0 END) AS died
    FROM rescue_evt r
    JOIN HIS.ORDERS d ON d.patient_id=r.patient_id AND d.visit_id=r.visit_id
      AND d.cancel_date_time IS NULL AND INSTR(d.order_text,'死亡')>0
    GROUP BY r.patient_id, r.visit_id, r.start_date_time
)
SELECT '指标 20：抢救记录及时完成率' AS 指标, TO_CHAR(r.discharge_date_time,'YYYY-MM') AS 月份,
    COUNT(*) - SUM(NVL(df.died,0)) AS 分子, COUNT(*) AS 分母,
    '可用-用户口径(大抢救成功率)' AS 说明
FROM rescue_evt r LEFT JOIN death_flag df ON df.patient_id=r.patient_id AND df.visit_id=r.visit_id AND df.start_date_time=r.start_date_time
GROUP BY TO_CHAR(r.discharge_date_time,'YYYY-MM')
ORDER BY 月份
