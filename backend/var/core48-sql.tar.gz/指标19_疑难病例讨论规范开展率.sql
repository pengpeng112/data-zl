/* ============================================================
   指标 19：疑难病例讨论规范开展率 （纯SELECT）
   ------------------------------------------------------------
   docx 口径依据：
  分子：规范开展（全科+≥2名主治以上）的讨论记录数（缺人员职称）
   分母：同期疑难病例讨论结论记录总数量
   统计期：2026-01-01 ~ 2026-08-01（左闭右开，1-7月）
   月份归属：按 HIS.PAT_VISIT.DISCHARGE_DATE_TIME
   输出：指标 | 月份 | 分子 | 分母 | 说明
   ============================================================ */
SELECT '指标 19：疑难病例讨论规范开展率' AS 指标,
    TO_CHAR(v.discharge_date_time,'YYYY-MM') AS 月份,
    CAST(NULL AS NUMBER) AS 分子,
    COUNT(*) AS 分母,
    '仅分母-缺参与人员职称结构化字段' AS 说明
FROM HIS.PAT_VISIT v
JOIN JHEMR.JHMR_FILE_INDEX f ON f.patient_id=v.patient_id AND f.visit_id=v.visit_id
WHERE v.discharge_date_time >= TO_DATE('2026-01-01 00:00:00','YYYY-MM-DD HH24:MI:SS') AND v.discharge_date_time < TO_DATE('2026-08-01 00:00:00','YYYY-MM-DD HH24:MI:SS') AND NVL(f.delete_flag,0)=0 AND f.first_mr_sign_date_time IS NOT NULL
  AND INSTR(NVL(f.topic,f.file_name),'疑难')>0 AND INSTR(NVL(f.topic,f.file_name),'讨论')>0
GROUP BY TO_CHAR(v.discharge_date_time,'YYYY-MM')
ORDER BY 月份
