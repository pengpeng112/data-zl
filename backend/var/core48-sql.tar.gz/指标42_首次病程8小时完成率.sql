/* ============================================================
   指标 42：首次病程记录8小时内完成率 （纯SELECT）
   ------------------------------------------------------------
   docx 口径依据：
  分子：首次病程记录在入院8h内完成的病历数
   分母：同期入院患者病历总数
   纳排：纳入住院>24h
   统计期：2026-01-01 ~ 2026-08-01（左闭右开，1-7月）
   月份归属：按 HIS.PAT_VISIT.DISCHARGE_DATE_TIME
   输出：指标 | 月份 | 分子 | 分母 | 说明
   ============================================================ */
SELECT '指标 42：首次病程记录8小时内完成率' AS 指标,
    TO_CHAR(v.discharge_date_time,'YYYY-MM') AS 月份,
    COUNT(DISTINCT CASE WHEN f.first_mr_sign_date_time <= v.admission_date_time + 8/24
                        THEN v.patient_id||'|'||v.visit_id END) AS 分子,
    COUNT(DISTINCT v.patient_id||'|'||v.visit_id) AS 分母,
    '可用' AS 说明
FROM HIS.PAT_VISIT v
LEFT JOIN JHEMR.JHMR_FILE_INDEX f
  ON f.patient_id=v.patient_id AND f.visit_id=v.visit_id
 AND NVL(f.delete_flag,0)=0 AND f.first_mr_sign_date_time IS NOT NULL
 AND f.mr_class = 'EMR10.00.01'
WHERE v.discharge_date_time >= TO_DATE('2026-01-01 00:00:00','YYYY-MM-DD HH24:MI:SS') AND v.discharge_date_time < TO_DATE('2026-08-01 00:00:00','YYYY-MM-DD HH24:MI:SS') AND v.discharge_date_time - v.admission_date_time > 1
GROUP BY TO_CHAR(v.discharge_date_time,'YYYY-MM')
ORDER BY 月份
