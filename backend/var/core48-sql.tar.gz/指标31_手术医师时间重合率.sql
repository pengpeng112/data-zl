/* ============================================================
   指标 31：手术医师手术时间重合率 （保留WITH：查询较复杂）
   ------------------------------------------------------------
   docx 口径依据：
  分子：手术医师和手术时间重合的手术例数（同术者，两台手术时间段重合）
   分母：同期住院患者手术总例数
   数据源：SM.MED_OPERATION_MASTER
   注：姓名口径，重名风险
   统计期：2026-01-01 ~ 2026-08-01（左闭右开，1-7月）
   月份归属：按 HIS.PAT_VISIT.DISCHARGE_DATE_TIME
   输出：指标 | 月份 | 分子 | 分母 | 说明
   ============================================================ */
WITH base_oper AS (
    SELECT m.patient_id, m.visit_id, m.oper_id, m.start_date_time, m.end_date_time,
           TRIM(m.surgeon) AS doctor_key, v.discharge_date_time
    FROM SM.MED_OPERATION_MASTER m
    JOIN HIS.PAT_VISIT v ON v.patient_id=m.patient_id AND v.visit_id=m.visit_id
    WHERE v.discharge_date_time >= TO_DATE('2026-01-01 00:00:00','YYYY-MM-DD HH24:MI:SS') AND v.discharge_date_time < TO_DATE('2026-08-01 00:00:00','YYYY-MM-DD HH24:MI:SS') AND m.visit_id>0 AND m.start_date_time IS NOT NULL AND m.end_date_time IS NOT NULL
      AND m.end_date_time > m.start_date_time AND m.oper_status >= 35
      AND m.cancel_date_time IS NULL AND m.surgeon IS NOT NULL
),
overlap_num AS (
    SELECT DISTINCT b.patient_id, b.visit_id, b.oper_id
    FROM base_oper b JOIN base_oper a ON a.doctor_key=b.doctor_key
      AND a.patient_id||'|'||a.visit_id||'|'||a.oper_id <> b.patient_id||'|'||b.visit_id||'|'||b.oper_id
      AND (a.start_date_time<b.start_date_time
           OR (a.start_date_time=b.start_date_time AND a.patient_id||'|'||a.visit_id||'|'||a.oper_id<b.patient_id||'|'||b.visit_id||'|'||b.oper_id))
      AND b.start_date_time < a.end_date_time
)
SELECT '指标 31：手术医师手术时间重合率' AS 指标, TO_CHAR(d.discharge_date_time,'YYYY-MM') AS 月份,
    COUNT(DISTINCT o.patient_id||'|'||o.visit_id||'|'||o.oper_id) AS 分子,
    COUNT(DISTINCT d.patient_id||'|'||d.visit_id||'|'||d.oper_id) AS 分母,
    '可用-姓名口径有重名风险' AS 说明
FROM base_oper d LEFT JOIN overlap_num o ON o.patient_id=d.patient_id AND o.visit_id=d.visit_id AND o.oper_id=d.oper_id
GROUP BY TO_CHAR(d.discharge_date_time,'YYYY-MM')
ORDER BY 月份
