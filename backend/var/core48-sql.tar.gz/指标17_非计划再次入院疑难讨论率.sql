/* ============================================================
   指标 17：非计划再次入院疑难病例讨论率 （保留WITH：查询较复杂）
   ------------------------------------------------------------
   docx 口径依据：
  docx纳排：①前次31天再入院计划为无或空(PLAN_31_ADMISSION='1')；②前次出院主诊断与本次入院主诊断亚目相同；③本次入院在前期出院后31天内；排除放化疗Z51.*
   统计期：2026-01-01 ~ 2026-08-01（左闭右开，1-7月）
   月份归属：按 HIS.PAT_VISIT.DISCHARGE_DATE_TIME
   输出：指标 | 月份 | 分子 | 分母 | 说明
   ============================================================ */
WITH readm AS (
    SELECT DISTINCT v.patient_id, v.visit_id, TO_CHAR(v.discharge_date_time,'YYYY-MM') AS 月份
    FROM HIS.PAT_VISIT v
    JOIN HIS.PAT_VISIT v0 ON v0.patient_id=v.patient_id AND v0.visit_id<>v.visit_id
       AND v0.discharge_date_time IS NOT NULL
       AND v.admission_date_time >= v0.discharge_date_time
       AND v.admission_date_time <  v0.discharge_date_time + 32
    JOIN HIS.DIAGNOSIS d ON d.patient_id=v.patient_id AND d.visit_id=v.visit_id AND d.diagnosis_type='3'
    JOIN HIS.DIAGNOSIS d0 ON d0.patient_id=v0.patient_id AND d0.visit_id=v0.visit_id AND d0.diagnosis_type='3'
       AND SUBSTR(d.diagnosis_code,1,5) = SUBSTR(d0.diagnosis_code,1,5)
    WHERE v.discharge_date_time >= TO_DATE('2026-01-01 00:00:00','YYYY-MM-DD HH24:MI:SS') AND v.discharge_date_time < TO_DATE('2026-08-01 00:00:00','YYYY-MM-DD HH24:MI:SS') AND v.plan_31_admission = '1'
      AND v.patient_id NOT IN (
        SELECT patient_id FROM HIS.DIAGNOSIS WHERE diagnosis_type='3'
          AND (diagnosis_code LIKE 'Z51.0%' OR diagnosis_code LIKE 'Z51.1%'
            OR diagnosis_code LIKE 'Z51.2%' OR diagnosis_code LIKE 'Z51.8%'))
),
disc_doc AS (
    SELECT r.patient_id, r.visit_id,
        MAX(CASE WHEN INSTR(NVL(f.topic,' '),'疑难')>0 AND INSTR(NVL(f.topic,' '),'讨论')>0 THEN 1 ELSE 0 END) AS done
    FROM readm r
    JOIN JHEMR.JHMR_FILE_INDEX f ON f.patient_id=r.patient_id AND f.visit_id=r.visit_id
    WHERE NVL(f.delete_flag,0)=0
    GROUP BY r.patient_id, r.visit_id
)
SELECT '指标 17：非计划再次入院疑难病例讨论率' AS 指标, r.月份, SUM(NVL(d.done,0)) AS 分子, COUNT(*) AS 分母,
    '候选-31天+诊断亚目+PLAN_31' AS 说明
FROM readm r LEFT JOIN disc_doc d ON d.patient_id=r.patient_id AND d.visit_id=r.visit_id
GROUP BY r.月份
ORDER BY 月份
