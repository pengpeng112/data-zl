/* ============================================================
   指标 7：术前手术知情同意书签署完成率 （纯SELECT）
   ------------------------------------------------------------
   docx 口径依据：
  分子：术前签署手术知情同意书数量
   分母：同期住院患者手术台次数量
   纳排：纳入住院手术；排除纸质同意书
   统计期：2026-01-01 ~ 2026-08-01（左闭右开，1-7月）
   月份归属：按 HIS.PAT_VISIT.DISCHARGE_DATE_TIME
   输出：指标 | 月份 | 分子 | 分母 | 说明
   ============================================================ */
SELECT '指标 7：术前手术知情同意书签署完成率' AS 指标,
    TO_CHAR(v.discharge_date_time,'YYYY-MM') AS 月份,
    COUNT(DISTINCT CASE WHEN f.first_mr_sign_date_time < o.start_date_time
                        THEN o.patient_id||'|'||o.visit_id||'|'||o.oper_id END) AS 分子,
    COUNT(DISTINCT o.patient_id||'|'||o.visit_id||'|'||o.oper_id) AS 分母,
    '可用' AS 说明
FROM HIS.OPERATION_MASTER o
JOIN HIS.PAT_VISIT v ON v.patient_id=o.patient_id AND v.visit_id=o.visit_id
LEFT JOIN JHEMR.JHMR_FILE_INDEX f
  ON f.patient_id=o.patient_id AND f.visit_id=o.visit_id
 AND NVL(f.delete_flag,0)=0 AND f.first_mr_sign_date_time IS NOT NULL
 AND f.mr_class = 'EMR07.00.01'
WHERE v.discharge_date_time >= TO_DATE('2026-01-01 00:00:00','YYYY-MM-DD HH24:MI:SS') AND v.discharge_date_time < TO_DATE('2026-08-01 00:00:00','YYYY-MM-DD HH24:MI:SS') AND o.start_date_time IS NOT NULL
GROUP BY TO_CHAR(v.discharge_date_time,'YYYY-MM')
ORDER BY 月份
