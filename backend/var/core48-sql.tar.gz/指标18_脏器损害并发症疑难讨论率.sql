/* ============================================================
   指标 18：手术后出现严重脏器功能损害的并发症的患者完成疑难病例讨论率 （保留WITH：查询较复杂）
   ------------------------------------------------------------
   docx 口径依据：
  分子：术后严重脏器损害并发症患者完成疑难讨论的数量
   分母：同期术后严重脏器损害并发症患者总数
   docx：病案首页有手术+入院病情=4的脏器衰竭诊断(I50/J98.403/K72/N17/N18)
   统计期：2026-01-01 ~ 2026-08-01（左闭右开，1-7月）
   月份归属：按 HIS.PAT_VISIT.DISCHARGE_DATE_TIME
   输出：指标 | 月份 | 分子 | 分母 | 说明
   ============================================================ */
WITH organ_pts AS (
    SELECT DISTINCT v.patient_id, v.visit_id, TO_CHAR(v.discharge_date_time,'YYYY-MM') AS 月份
    FROM HIS.PAT_VISIT v
    WHERE v.discharge_date_time >= TO_DATE('2026-01-01 00:00:00','YYYY-MM-DD HH24:MI:SS') AND v.discharge_date_time < TO_DATE('2026-08-01 00:00:00','YYYY-MM-DD HH24:MI:SS')
      AND EXISTS (SELECT 1 FROM HIS.OPERATION_MASTER o WHERE o.patient_id=v.patient_id AND o.visit_id=v.visit_id)
      AND EXISTS (SELECT 1 FROM HIS.DIAGNOSIS d WHERE d.patient_id=v.patient_id AND d.visit_id=v.visit_id
        AND d.diagnosis_type='3' AND d.admission_condition='4'
        AND (d.diagnosis_code LIKE 'I50%' OR d.diagnosis_code='J98.403'
          OR d.diagnosis_code LIKE 'K72%' OR d.diagnosis_code LIKE 'N17%' OR d.diagnosis_code LIKE 'N18%'))
),
disc_doc AS (
    SELECT p.patient_id, p.visit_id,
        MAX(CASE WHEN INSTR(NVL(f.topic,' '),'疑难')>0 AND INSTR(NVL(f.topic,' '),'讨论')>0 THEN 1 ELSE 0 END) AS done
    FROM organ_pts p
    JOIN JHEMR.JHMR_FILE_INDEX f ON f.patient_id=p.patient_id AND f.visit_id=p.visit_id
    WHERE NVL(f.delete_flag,0)=0
    GROUP BY p.patient_id, p.visit_id
)
SELECT '指标 18：手术后出现严重脏器功能损害的并发症的患者完成疑难病例讨论率' AS 指标, p.月份, SUM(NVL(d.done,0)) AS 分子, COUNT(*) AS 分母,
    '可用-按docx入院病情=4+脏器衰竭ICD' AS 说明
FROM organ_pts p LEFT JOIN disc_doc d ON d.patient_id=p.patient_id AND d.visit_id=p.visit_id
GROUP BY p.月份
ORDER BY 月份
