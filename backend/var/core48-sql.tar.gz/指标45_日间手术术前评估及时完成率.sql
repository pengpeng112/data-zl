/* ============================================================
   指标 45：日间手术术前评估及时完成率 （纯SELECT）
   ------------------------------------------------------------
   docx 口径依据：
  分子：日间手术术前评估记录在手术开始前完成的病例数
   分母：同期日间手术病例数
   日间判定：HIS.OPERATION.PRIMARY_DAY='1'
   术前评估：标题含'评估'文书签名<手术日期（无独立模板，近似）
   统计期：2026-01-01 ~ 2026-08-01（左闭右开，1-7月）
   月份归属：按 HIS.PAT_VISIT.DISCHARGE_DATE_TIME
   输出：指标 | 月份 | 分子 | 分母 | 说明
   ============================================================ */
SELECT '指标 45：日间手术术前评估及时完成率' AS 指标,
    TO_CHAR(v.discharge_date_time,'YYYY-MM') AS 月份,
    COUNT(DISTINCT CASE WHEN f.first_mr_sign_date_time < op.operating_date
                        THEN op.patient_id||'|'||op.visit_id||'|'||op.oper_id END) AS 分子,
    COUNT(DISTINCT op.patient_id||'|'||op.visit_id||'|'||op.oper_id) AS 分母,
    '有限可用-评估文书近似' AS 说明
FROM HIS.OPERATION op
JOIN HIS.PAT_VISIT v ON v.patient_id=op.patient_id AND v.visit_id=op.visit_id
LEFT JOIN JHEMR.JHMR_FILE_INDEX f
  ON f.patient_id=op.patient_id AND f.visit_id=op.visit_id
 AND NVL(f.delete_flag,0)=0 AND f.first_mr_sign_date_time IS NOT NULL
 AND INSTR(NVL(f.topic,f.file_name),'评估')>0
WHERE op.primary_day='1' AND op.operating_date IS NOT NULL AND v.discharge_date_time >= TO_DATE('2026-01-01 00:00:00','YYYY-MM-DD HH24:MI:SS') AND v.discharge_date_time < TO_DATE('2026-08-01 00:00:00','YYYY-MM-DD HH24:MI:SS')
GROUP BY TO_CHAR(v.discharge_date_time,'YYYY-MM')
ORDER BY 月份
