/* ============================================================
   指标 27：死亡病例讨论及时完成率 （保留WITH：查询较复杂）
   ------------------------------------------------------------
   docx 口径依据：
  分子：死亡讨论结论记录在死亡后5个工作日内完成的病历数
   分母：同期住院死亡患者病例总数
   注：ODS无节假日日历，用死亡后7自然日近似5工作日（用户确认）
   统计期：2026-01-01 ~ 2026-08-01（左闭右开，1-7月）
   月份归属：按 HIS.PAT_VISIT.DISCHARGE_DATE_TIME
   输出：指标 | 月份 | 分子 | 分母 | 说明
   ============================================================ */
WITH death_visits AS (
    SELECT patient_id, visit_id, death_date_time, TO_CHAR(discharge_date_time,'YYYY-MM') AS 月份
    FROM HIS.PAT_VISIT v WHERE v.discharge_date_time >= TO_DATE('2026-01-01 00:00:00','YYYY-MM-DD HH24:MI:SS') AND v.discharge_date_time < TO_DATE('2026-08-01 00:00:00','YYYY-MM-DD HH24:MI:SS') AND v.discharge_disposition = '5'
),
death_time2 AS (
    SELECT dv.patient_id, dv.visit_id, dv.月份,
           COALESCE(dv.death_date_time, MIN(NVL(o.start_date_time,o.enter_date_time))) AS death_time
    FROM death_visits dv
    LEFT JOIN HIS.ORDERS o ON o.patient_id=dv.patient_id AND o.visit_id=dv.visit_id
      AND o.cancel_date_time IS NULL AND INSTR(NVL(o.order_text,' '),'死亡')>0
    GROUP BY dv.patient_id, dv.visit_id, dv.月份, dv.death_date_time
),
disc_done AS (
    SELECT dv.patient_id, dv.visit_id,
        MAX(CASE WHEN f.mr_class IN ('EMR10.00.15','EMR10.00.19')
                  AND f.first_mr_sign_date_time >= dv.death_time
                  AND f.first_mr_sign_date_time <  TRUNC(dv.death_time) + 8 THEN 1 ELSE 0 END) AS done
    FROM death_time2 dv
    JOIN JHEMR.JHMR_FILE_INDEX f ON f.patient_id=dv.patient_id AND f.visit_id=dv.visit_id
    WHERE NVL(f.delete_flag,0)=0 AND f.first_mr_sign_date_time IS NOT NULL
    GROUP BY dv.patient_id, dv.visit_id, dv.death_time
)
SELECT '指标 27：死亡病例讨论及时完成率' AS 指标, dv.月份, SUM(NVL(d.done,0)) AS 分子, COUNT(*) AS 分母,
    '有限可用-7自然日近似5工作日' AS 说明
FROM death_time2 dv LEFT JOIN disc_done d ON d.patient_id=dv.patient_id AND d.visit_id=dv.visit_id
WHERE dv.death_time IS NOT NULL
GROUP BY dv.月份
ORDER BY 月份
