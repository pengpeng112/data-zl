/* ============================================================
   指标 10：诊疗方案决策权医师审核率 （纯SELECT）
   ------------------------------------------------------------
   docx 口径依据：
  分子：决策权医师审核签字病历数（缺授权名单，无法提取）
   分母：所有住院患者例数
   纳排：纳入住院>24h
   统计期：2026-01-01 ~ 2026-08-01（左闭右开，1-7月）
   月份归属：按 HIS.PAT_VISIT.DISCHARGE_DATE_TIME
   输出：指标 | 月份 | 分子 | 分母 | 说明
   ============================================================ */
SELECT '指标 10：诊疗方案决策权医师审核率' AS 指标,
    TO_CHAR(v.discharge_date_time,'YYYY-MM') AS 月份,
    CAST(NULL AS NUMBER) AS 分子,
    COUNT(*) AS 分母,
    '仅分母-缺决策权授权名单' AS 说明
FROM HIS.PAT_VISIT v
WHERE v.discharge_date_time >= TO_DATE('2026-01-01 00:00:00','YYYY-MM-DD HH24:MI:SS') AND v.discharge_date_time < TO_DATE('2026-08-01 00:00:00','YYYY-MM-DD HH24:MI:SS') AND v.discharge_date_time - v.admission_date_time > 1
GROUP BY TO_CHAR(v.discharge_date_time,'YYYY-MM')
ORDER BY 月份
