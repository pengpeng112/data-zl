"""Read-only smoke of platform state on 8.83."""
from __future__ import annotations

import io
import os

import paramiko

HOST = os.environ.get("APP_SSH_HOST", "10.10.8.83")
PASSWORD = os.environ.get("APP_SSH_PASSWORD", "P@ssw0rd@123")
CONTAINER = "data-asset-api"

REMOTE_PY = r"""
from app.core.db import SessionLocal
from sqlalchemy import text
db = SessionLocal()
out = {}
try:
    out["tables"] = db.execute(text("select count(*) from asset.asset_tables")).scalar()
    out["columns"] = db.execute(text("select count(*) from asset.asset_columns")).scalar()
    out["relations"] = db.execute(text("select count(*) from asset.asset_relations")).scalar()
    out["open_diffs"] = db.execute(
        text("select count(*) from asset.asset_identity_sync_diffs where status='open'")
    ).scalar()
    out["persons"] = db.execute(text("select count(*) from asset.asset_identity_persons")).scalar()
    out["q_runs"] = db.execute(text("select count(*) from asset.asset_quality_check_runs")).scalar()
    out["snaps"] = db.execute(text("select count(*) from asset.asset_metadata_snapshots")).scalar()
    try:
        rows = db.execute(
            text(
                "select id, job_type, schedule_cron, trigger_mode, status, source_code "
                "from asset.asset_scheduler_jobs order by id desc limit 15"
            )
        ).mappings().all()
        out["jobs"] = [dict(r) for r in rows]
    except Exception as e:
        out["jobs_err"] = str(e)[:300]
    print(out)
finally:
    db.close()
"""


def main() -> None:
    c = paramiko.SSHClient()
    c.set_missing_host_key_policy(paramiko.AutoAddPolicy())
    c.connect(HOST, username="root", password=PASSWORD, timeout=20, allow_agent=False, look_for_keys=False)
    sftp = c.open_sftp()
    try:
        sftp.putfo(io.BytesIO(REMOTE_PY.encode()), "/tmp/smoke_state.py")
        _, o, e = c.exec_command(
            f"docker cp /tmp/smoke_state.py {CONTAINER}:/tmp/smoke_state.py; "
            f"docker exec -e PYTHONPATH=/app -w /app {CONTAINER} python /tmp/smoke_state.py",
            timeout=60,
        )
        print(o.read().decode("utf-8", "replace"))
        err = e.read().decode("utf-8", "replace")
        if err:
            print("ERR", err[:1000])
    finally:
        sftp.close()
        c.close()


if __name__ == "__main__":
    main()
