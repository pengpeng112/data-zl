import oracledb, os
try: oracledb.init_oracle_client(lib_dir="/opt/oracle")
except Exception: pass
conn = oracledb.connect(user=os.environ["HIS_USER"], password=os.environ["HIS_PWD"], dsn="10.10.10.15:1521/his")
conn.call_timeout = 30000
cur = conn.cursor()
cur.execute("SET TRANSACTION READ ONLY")
def run(label, sql):
    try:
        cur.execute(sql)
        rows = cur.fetchmany(25)
        print(f"=== {label} ===")
        for r in rows: print("  ", r)
        if not rows: print("  (无数据)")
    except Exception as e:
        print(f"=== {label} ERR: {str(e)[:150]}")

# 1. 6 张表的 Owner 归属
print("=== 0. 表归属 ===")
for t in ["OUTP_ORDERS","OUTP_TREAT_REC","OUTP_ORDERS_COSTS","LAB_TEST_MASTER","LAB_TEST_ITEMS","CLINIC_VS_CHARGE"]:
    r = cur.execute(f"SELECT owner FROM all_tables WHERE table_name='{t}'").fetchone()
    print(f"  {t}: {r[0] if r else '不存在'}")

# 2. 各表字段(关键列存在性)
run("OUTP_ORDERS_COSTS 字段", "SELECT column_name FROM all_tab_columns WHERE table_name='OUTP_ORDERS_COSTS' ORDER BY column_id")
run("OUTP_TREAT_REC 关键列", "SELECT column_name FROM all_tab_columns WHERE table_name='OUTP_TREAT_REC' AND column_name IN ('VISIT_DATE','VISIT_NO','SERIAL_NO','ITEM_NO','ITEM_CLASS','ITEM_CODE','ITEM_NAME','AMOUNT','PERFORMED_BY','CHARGE_INDICATOR','ORDER_ID','ORDER_ITEM_ID') ORDER BY column_id")

# 3. 门诊 OUTP_TREAT_REC(0502+C) 前缀分布 近6月
run("门诊0502 C 前缀分布", """SELECT substr(ITEM_NAME,1,2) pfx, count(*) FROM OUTPADM.OUTP_TREAT_REC
WHERE VISIT_DATE>=ADD_MONTHS(SYSDATE,-6) AND ITEM_CLASS='C' AND PERFORMED_BY='0502'
GROUP BY substr(ITEM_NAME,1,2) ORDER BY 2 DESC""")

# 4. 住院 LAB_TEST_MASTER(0502) 前缀分布 近3月
run("住院0502 前缀分布", """SELECT CASE WHEN i.ITEM_NAME LIKE 'DT%' THEN 'DT' WHEN i.ITEM_NAME LIKE 'DP%' THEN 'DP'
  WHEN i.ITEM_NAME LIKE 'WK%' THEN 'WK' WHEN i.ITEM_NAME LIKE 'BR%' THEN 'BR'
  WHEN i.ITEM_CODE LIKE 'WS%' THEN 'WS' ELSE substr(i.ITEM_NAME,1,2) END pfx, count(*) cnt
FROM LAB.LAB_TEST_MASTER m JOIN LAB.LAB_TEST_ITEMS i ON m.TEST_NO=i.TEST_NO
WHERE m.REQUESTED_DATE_TIME>=ADD_MONTHS(SYSDATE,-3) AND m.VISIT_ID>0 AND m.PERFORMED_BY='0502'
GROUP BY CASE WHEN i.ITEM_NAME LIKE 'DT%' THEN 'DT' WHEN i.ITEM_NAME LIKE 'DP%' THEN 'DP'
  WHEN i.ITEM_NAME LIKE 'WK%' THEN 'WK' WHEN i.ITEM_NAME LIKE 'BR%' THEN 'BR'
  WHEN i.ITEM_CODE LIKE 'WS%' THEN 'WS' ELSE substr(i.ITEM_NAME,1,2) END ORDER BY cnt DESC""")

# 5. BR 前缀样本(确认是不是外送)
run("BR 前缀样本", "SELECT DISTINCT ITEM_NAME FROM LAB.LAB_TEST_ITEMS WHERE ITEM_NAME LIKE 'BR%' AND ROWNUM<=10")

# 6. WS 编码但名称不带 DT/DP/WK 的(看 WS 是不是更全)
run("WS编码 非DTDPWK 样本", "SELECT DISTINCT ITEM_CODE,ITEM_NAME FROM LAB.LAB_TEST_ITEMS WHERE ITEM_CODE LIKE 'WS%' AND ITEM_NAME NOT LIKE 'DT%' AND ITEM_NAME NOT LIKE 'DP%' AND ITEM_NAME NOT LIKE 'WK%' AND ROWNUM<=10")

cur.close(); conn.close()
