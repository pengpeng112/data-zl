"""Browser-acceptance oriented probe: nginx, SPA, APIs with login if possible."""
from __future__ import annotations

import json
import os
import re
from pathlib import Path

import paramiko

HOST = os.environ.get("APP_SSH_HOST", "10.10.8.83")
PASSWORD = os.environ.get("APP_SSH_PASSWORD", "P@ssw0rd@123")
# Optional: set APP_ADMIN_PASSWORD for authenticated API checks
ADMIN_USER = os.environ.get("APP_ADMIN_USER", "platform-admin")
ADMIN_PASS = os.environ.get("APP_ADMIN_PASSWORD", "")


def run(c, cmd, timeout=60):
    _, o, e = c.exec_command(cmd, timeout=timeout)
    return o.channel.recv_exit_status(), o.read().decode("utf-8", "replace"), e.read().decode("utf-8", "replace")


def main():
    c = paramiko.SSHClient()
    c.set_missing_host_key_policy(paramiko.AutoAddPolicy())
    c.connect(HOST, username="root", password=PASSWORD, timeout=20, allow_agent=False, look_for_keys=False)
    try:
        checks = []
        for label, cmd in [
            ("nginx_root", "curl -sS -o /dev/null -w '%{http_code}' http://127.0.0.1/"),
            ("nginx_login", "curl -sS -o /dev/null -w '%{http_code}' http://127.0.0.1/login"),
            ("api_health_via_nginx", "curl -sS -o /dev/null -w '%{http_code}' http://127.0.0.1/api/v1/health || true"),
            ("api_docs_direct", "curl -sS -o /dev/null -w '%{http_code}' http://127.0.0.1:8000/docs"),
            ("api_health_direct", "curl -sS http://127.0.0.1:8000/health"),
            ("spa_index_title", "grep -o '<title>[^<]*</title>' /usr/share/nginx/html/index.html || true"),
            ("spa_assets", "ls /usr/share/nginx/html/static/js 2>/dev/null | wc -l"),
        ]:
            code, out, err = run(c, cmd)
            checks.append({"label": label, "exit": code, "out": (out or err).strip()[:300]})

        # nginx config snippets
        code, out, err = run(
            c,
            "grep -nE 'location|proxy_pass|try_files' /etc/nginx/nginx.conf /etc/nginx/conf.d/*.conf 2>/dev/null | head -60",
        )
        checks.append({"label": "nginx_routes", "out": (out or err)[:2000]})

        # try login
        if ADMIN_PASS:
            login_cmd = (
                "curl -sS -c /tmp/ba_cookie.txt -H 'Content-Type: application/json' "
                f"-d '{{\"username\":\"{ADMIN_USER}\",\"password\":\"{ADMIN_PASS}\"}}' "
                "http://127.0.0.1:8000/api/v1/auth/login"
            )
            code, out, err = run(c, login_cmd)
            checks.append({"label": "login_raw", "out": out[:500] if out else err[:500]})
            # extract token if json
            try:
                data = json.loads(out)
                token = (
                    (data.get("data") or {}).get("access_token")
                    or (data.get("data") or {}).get("token")
                    or data.get("access_token")
                )
            except Exception:
                token = None
            if token:
                for path in [
                    "/api/v1/dashboard/summary",
                    "/api/v1/assets/tree",
                    "/api/v1/tables?page=1&page_size=5",
                    "/api/v1/identity/sync-diffs?status=open&page=1&page_size=5",
                    "/api/v1/quality/findings?page=1&page_size=5",
                    "/api/v1/quality/checks/runs?page=1&page_size=5",
                    "/api/v1/identity/persons?page=1&page_size=3",
                    "/api/v1/relations?page=1&page_size=5",
                ]:
                    cmd = (
                        f"curl -sS -H 'Authorization: Bearer {token}' "
                        f"-o /tmp/ba_body.json -w '%{{http_code}}' "
                        f"http://127.0.0.1:8000{path}"
                    )
                    code, out, err = run(c, cmd)
                    body_code, body, _ = run(c, "head -c 400 /tmp/ba_body.json")
                    checks.append(
                        {
                            "label": f"auth {path}",
                            "http": out.strip(),
                            "body": body[:400],
                        }
                    )
        else:
            checks.append(
                {
                    "label": "login_skipped",
                    "out": "Set APP_ADMIN_PASSWORD for authenticated API probe",
                }
            )

        print(json.dumps(checks, ensure_ascii=False, indent=2))
    finally:
        c.close()


if __name__ == "__main__":
    main()
