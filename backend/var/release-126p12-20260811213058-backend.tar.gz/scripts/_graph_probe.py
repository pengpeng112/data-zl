import json, urllib.request
from app.core.db import SessionLocal
from sqlalchemy import text
from app.services.auth_service import hash_password

# 1. 临时重置密码
s = SessionLocal(); s.rollback()
TMP = "GraphProbe123!"
old = s.execute(text("SELECT password_hash FROM asset.asset_auth_users WHERE username='platform-admin'")).scalar()
s.execute(text("UPDATE asset.asset_auth_users SET password_hash=:h, must_change_password=false WHERE username='platform-admin'"), {"h": hash_password(TMP)})
s.commit(); s.close()

def post(url, data):
    req = urllib.request.Request(url, data=json.dumps(data).encode(),
        headers={"Content-Type":"application/json","X-Requested-With":"XMLHttpRequest"})
    r = urllib.request.urlopen(req, timeout=15); return json.loads(r.read())
def get(url, token):
    req = urllib.request.Request(url, headers={"Authorization":"Bearer "+token,"X-Requested-With":"XMLHttpRequest"})
    try:
        r = urllib.request.urlopen(req, timeout=30); return r.status, json.loads(r.read())
    except urllib.error.HTTPError as e:
        return e.code, json.loads(e.read())
    except Exception as e:
        return "ERR", str(e)[:200]

BASE = "http://127.0.0.1:8000"
login = post(BASE+"/api/v1/auth/login", {"username":"platform-admin","password":TMP})
token = login["data"]["accessToken"] if login.get("code")==0 else None
print("登录:", "OK" if token else "FAIL "+str(login)[:150])

if token:
    # 2. 三个图谱 API
    for path in ["/api/v1/graph/options", "/api/v1/graph?confidence=A&limit=120", "/api/v1/graph/diagnostics"]:
        st, resp = get(BASE+path, token)
        print(f"\n=== {path} ===")
        print(f"status={st}")
        if isinstance(resp, dict):
            d = resp.get("data", resp)
            if "nodes" in d or "edges" in d:
                nodes = d.get("nodes", [])
                edges = d.get("edges", [])
                print(f"nodes={len(nodes)} edges={len(edges)}")
                # 检查边重复(Edge already exists 根因)
                if edges:
                    edge_ids = [e.get("id") or e.get("source","")+"-"+e.get("target","") for e in edges]
                    unique_ids = set()
                    dup = 0
                    empty_ep = 0
                    self_loop = 0
                    for e in edges:
                        eid = e.get("id") or (str(e.get("source",""))+"-"+str(e.get("target","")))
                        if eid in unique_ids: dup += 1
                        unique_ids.add(eid)
                        src, tgt = e.get("source"), e.get("target")
                        if not src or not tgt: empty_ep += 1
                        if src == tgt: self_loop += 1
                    print(f"边重复ID数={dup} 空端点={empty_ep} 自环={self_loop}")
                    # 检查端点是否都在节点里
                    node_ids = {str(n.get("id")) for n in nodes}
                    orphan = sum(1 for e in edges if str(e.get("source","")) not in node_ids or str(e.get("target","")) not in node_ids)
                    print(f"孤儿边(端点不在节点)={orphan}")
                    # 样本
                    if edges:
                        print(f"边样本: {json.dumps(edges[0], ensure_ascii=False)[:200]}")
                else:
                    print(f"data keys: {list(d.keys())[:10]}")
                    print(f"response snippet: {json.dumps(d, ensure_ascii=False)[:300]}")
            else:
                print(f"keys: {list(d.keys())[:10] if isinstance(d,dict) else type(d)}")
                print(f"snippet: {json.dumps(resp, ensure_ascii=False)[:300]}")

# 3. 恢复密码
s2 = SessionLocal()
s2.execute(text("UPDATE asset.asset_auth_users SET password_hash=:h WHERE username='platform-admin'"), {"h": old})
s2.commit(); s2.close()
print("\n密码已恢复")
