"""Re-upload fixed import script + CSV and run import on 8.83."""
from __future__ import annotations

import os
import tarfile
import tempfile
import time
from pathlib import Path

import paramiko

ROOT = Path(__file__).resolve().parents[2]
CSV_DIR = ROOT / "开发起步包" / "数据资产_ODS_HIS归一优化包"
SCRIPT = ROOT / "backend" / "scripts" / "import_normalized_to_platform.py"
HOST = os.environ.get("APP_SSH_HOST", "10.10.8.83")
PASSWORD = os.environ.get("APP_SSH_PASSWORD", "P@ssw0rd@123")
CONTAINER = "data-asset-api"


def run(client, cmd, timeout=900):
    _i, o, e = client.exec_command(cmd, timeout=timeout)
    return o.channel.recv_exit_status(), o.read().decode("utf-8", "replace"), e.read().decode("utf-8", "replace")


def main():
    client = paramiko.SSHClient()
    client.set_missing_host_key_policy(paramiko.AutoAddPolicy())
    client.connect(HOST, username="root", password=PASSWORD, timeout=20, allow_agent=False, look_for_keys=False)
    sftp = client.open_sftp()
    try:
        sftp.put(str(SCRIPT), "/tmp/import_normalized_to_platform.py")
        run(client, f"docker cp /tmp/import_normalized_to_platform.py {CONTAINER}:/app/scripts/import_normalized_to_platform.py")

        # ensure csv present
        code, out, err = run(client, f"docker exec {CONTAINER} test -f /tmp/normalized/normalized_tables.csv && echo OK || echo MISSING")
        if "MISSING" in out:
            fd, name = tempfile.mkstemp(suffix="-csv.tar.gz")
            os.close(fd)
            with tarfile.open(name, "w:gz") as tar:
                for f in CSV_DIR.glob("normalized_*"):
                    tar.add(f, arcname=f"normalized/{f.name}")
            sftp.put(name, "/tmp/normalized_pkg.tar.gz")
            Path(name).unlink(missing_ok=True)
            run(client, "mkdir -p /tmp/normalized; tar -xzf /tmp/normalized_pkg.tar.gz -C /tmp; docker cp /tmp/normalized data-asset-api:/tmp/normalized")

        print("== import ==")
        code, out, err = run(
            client,
            f"docker exec {CONTAINER} bash -lc "
            "'cd /app && PYTHONPATH=/app python scripts/import_normalized_to_platform.py "
            "--csv-dir /tmp/normalized --force --columns-limit 80000'",
            timeout=900,
        )
        print("exit", code)
        print(out)
        if err:
            print("ERR", err[:3000])

        print("== counts ==")
        py = (
            "from app.core.db import SessionLocal\n"
            "from sqlalchemy import text\n"
            "db=SessionLocal()\n"
            "for t in ['asset_tables','asset_columns','asset_relations','asset_systems','asset_data_sources']:\n"
            "    n=db.execute(text('select count(*) from asset.' + t)).scalar()\n"
            "    print(t, n)\n"
            "db.close()\n"
        )
        # write remote py to avoid quoting hell
        sftp.putfo(__import__("io").BytesIO(py.encode()), "/tmp/count_asset.py")
        run(client, f"docker cp /tmp/count_asset.py {CONTAINER}:/tmp/count_asset.py")
        code, out, err = run(client, f"docker exec {CONTAINER} bash -lc 'cd /app && PYTHONPATH=/app python /tmp/count_asset.py'")
        print(out or err)
    finally:
        sftp.close()
        client.close()


if __name__ == "__main__":
    main()
