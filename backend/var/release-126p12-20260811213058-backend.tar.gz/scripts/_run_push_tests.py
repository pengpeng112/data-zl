import os
import re
import subprocess
import sys
from pathlib import Path

root = Path(__file__).resolve().parents[1]
env_path = root / ".env"
text = env_path.read_text(encoding="utf-8", errors="ignore") if env_path.exists() else ""
m = re.search(r"^APP_DB_URL=(.+)$", text, re.M)
if not m:
    print("APP_DB_URL not found in .env; skip integration tests")
    sys.exit(0)
url = m.group(1).strip().strip('"').strip("'")
if url.rstrip("/").endswith("data_asset"):
    test_url = url[: -len("data_asset")] + "data_asset_test"
else:
    test_url = url.rsplit("/", 1)[0] + "/data_asset_test"
os.environ["APP_TEST_DB_URL"] = test_url
os.environ["APP_DB_URL"] = test_url
os.environ["APP_RATE_LIMIT_ENABLED"] = "false"
print("using test db suffix:", test_url.rsplit("@", 1)[-1])
cmd = [sys.executable, "-m", "pytest", "tests/test_medical_code_push.py", "-q", "--tb=short"]
raise SystemExit(subprocess.call(cmd, cwd=str(root)))
