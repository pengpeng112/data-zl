"""Probe platform sources and run read-only connectivity from 8.83 / jump host."""

from __future__ import annotations

import json
import paramiko

HOST = "10.10.8.83"
PASSWORD = "P@ssw0rd@123"


def run(c, cmd, timeout=120):
    _i, o, e = c.exec_command(cmd, timeout=timeout)
    out = o.read().decode("utf-8", "replace")
    err = e.read().decode("utf-8", "replace")
    code = o.channel.recv_exit_status()
    return code, out, err


def main() -> None:
    c = paramiko.SSHClient()
    c.set_missing_host_key_policy(paramiko.AutoAddPolicy())
    c.connect(HOST, username="root", password=PASSWORD, timeout=15, allow_agent=False, look_for_keys=False)

    cmds = [
        "ls -la /etc/data-asset/ 2>/dev/null; ls -la /etc/data-asset/credentials 2>/dev/null || true",
        "docker exec data-asset-api printenv | grep -E 'HIS|ODS|SOURCE|ORACLE|JUMP|CRED' | sed -E 's/(PASSWORD|SECRET|KEY|TOKEN)=.*/\\1=***/I' || true",
        "cut -d= -f1 /etc/data-asset/backend.env",
        # table structure
        "sudo -u postgres /usr/local/pgsql/bin/psql -d data_asset -c \"\\d asset.asset_data_sources\" 2>&1 | head -50",
        "sudo -u postgres /usr/local/pgsql/bin/psql -d data_asset -c \"SELECT column_name,data_type FROM information_schema.columns WHERE table_schema='asset' AND table_name='asset_data_sources' ORDER BY ordinal_position\" 2>&1",
        "sudo -u postgres /usr/local/pgsql/bin/psql -d data_asset -c \"SELECT * FROM asset.asset_data_sources LIMIT 5\" 2>&1 | head -60",
        "sudo -u postgres /usr/local/pgsql/bin/psql -d data_asset -c \"SELECT id,system_code,name_cn FROM asset.asset_systems LIMIT 20\" 2>&1 | head -40",
        # network from 8.83 to oracle ports
        "timeout 3 bash -c 'echo >/dev/tcp/10.10.8.216/1521' && echo ODS_PORT_OPEN || echo ODS_PORT_CLOSED",
        "timeout 3 bash -c 'echo >/dev/tcp/10.10.10.15/1521' && echo HIS_PORT_OPEN || echo HIS_PORT_CLOSED",
        "timeout 3 bash -c 'echo >/dev/tcp/10.10.8.53/40022' && echo JUMP_PORT_OPEN || echo JUMP_PORT_CLOSED",
        "ls -ld /opt/oracle/instantclient_21 2>/dev/null || ls -ld /opt/oracle 2>/dev/null || echo NO_ORACLE_CLIENT",
        "docker exec data-asset-api ls /opt/oracle 2>/dev/null | head || echo NO_ORACLE_IN_CONTAINER",
        "docker exec data-asset-api python -c \"import oracledb; print('oracledb', oracledb.__version__)\" 2>&1",
    ]
    for cmd in cmds:
        code, out, err = run(c, cmd)
        print("===", cmd[:100])
        print(out[:2500])
        if err and "could not change directory" not in err:
            print("ERR", err[:300])
    c.close()


if __name__ == "__main__":
    main()
