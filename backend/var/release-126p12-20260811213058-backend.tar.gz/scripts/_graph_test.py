import sys, json, traceback
sys.path.insert(0, '/app')
from app.core.db import SessionLocal
from sqlalchemy import select
from app.models.asset import AssetRelation
from app.api.v1.graph import _nodes_and_edges_for_relations

s = SessionLocal()
rows = s.scalars(select(AssetRelation).limit(120)).all()
print(f"relations: {len(rows)}")
try:
    nodes, edges, unresolved = _nodes_and_edges_for_relations(s, rows)
    print(f"nodes={len(nodes)} edges={len(edges)} unresolved={len(unresolved)}")
    # 检查重复/自环
    ids = [e["id"] for e in edges]
    dups = len(ids) - len(set(ids))
    self_loops = sum(1 for e in edges if e["source"] == e["target"])
    print(f"重复边ID={dups} 自环边={self_loops}")
    print(f"unresolved 样本: {unresolved[:5]}")
except Exception as e:
    traceback.print_exc()
s.close()
