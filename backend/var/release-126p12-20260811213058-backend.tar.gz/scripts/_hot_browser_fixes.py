"""Hot-deploy browser-accept fixes to 8.83 and re-verify key APIs."""
from __future__ import annotations

import io
import json
import os
import tarfile
import tempfile
import time
from pathlib import Path

import paramiko

ROOT = Path(__file__).resolve().parents[2]
HOST = os.environ.get("APP_SSH_HOST", "10.10.8.83")
PASSWORD = os.environ.get("APP_SSH_PASSWORD", "P@ssw0rd@123")
CONTAINER = "data-asset-api"


def run(c, cmd, timeout=300):
    _, o, e = c.exec_command(cmd, timeout=timeout)
    return o.channel.recv_exit_status(), o.read().decode("utf-8", "replace"), e.read().decode("utf-8", "replace")


def main():
    c = paramiko.SSHClient()
    c.set_missing_host_key_policy(paramiko.AutoAddPolicy())
    c.connect(HOST, username="root", password=PASSWORD, timeout=20, allow_agent=False, look_for_keys=False)
    sftp = c.open_sftp()
    try:
        backend_files = {
            ROOT / "backend/app/api/v1/tables.py": "/tmp/tables.py",
            ROOT / "backend/app/api/v1/health.py": "/tmp/health.py",
        }
        for local, remote in backend_files.items():
            sftp.put(str(local), remote)
        run(
            c,
            f"docker cp /tmp/tables.py {CONTAINER}:/app/app/api/v1/tables.py; "
            f"docker cp /tmp/health.py {CONTAINER}:/app/app/api/v1/health.py; "
            f"docker restart {CONTAINER}",
        )
        time.sleep(8)

        dist = ROOT / "frontend" / "dist"
        if dist.exists():
            fd, tname = tempfile.mkstemp(suffix=".tar.gz")
            os.close(fd)
            with tarfile.open(tname, "w:gz") as tar:
                tar.add(dist, arcname="dist")
            sftp.put(tname, "/tmp/fe_dist_ba.tar.gz")
            Path(tname).unlink(missing_ok=True)
            run(
                c,
                "mkdir -p /tmp/fe_ba && tar -xzf /tmp/fe_dist_ba.tar.gz -C /tmp/fe_ba && "
                "rsync -a --delete /tmp/fe_ba/dist/ /usr/share/nginx/html/ 2>/dev/null || "
                "cp -a /tmp/fe_ba/dist/. /usr/share/nginx/html/; nginx -s reload 2>/dev/null || true",
            )

        mint = (
            "from app.core.db import SessionLocal\n"
            "from app.models.auth import AuthUser\n"
            "from app.services.auth_service import create_access_token\n"
            "from sqlalchemy import select\n"
            "db=SessionLocal()\n"
            "u=db.scalar(select(AuthUser).where(AuthUser.enabled==True).limit(1))\n"
            "t,_=create_access_token(u); print(t); db.close()\n"
        )
        sftp.putfo(io.BytesIO(mint.encode()), "/tmp/mint2.py")
        run(c, f"docker cp /tmp/mint2.py {CONTAINER}:/tmp/mint2.py")
        code, out, err = run(
            c, f"docker exec -e PYTHONPATH=/app -w /app {CONTAINER} python /tmp/mint2.py"
        )
        token = out.strip().splitlines()[-1]
        checks = []
        for path in [
            "/api/v1/dashboard/summary",
            "/api/v1/health",
            "/health",
            "/api/v1/assets/tree",
            "/api/v1/tables?page=1&page_size=3",
        ]:
            code, http, err = run(
                c,
                f"curl -sS -H 'Authorization: Bearer {token}' -o /tmp/ba2.json -w '%{{http_code}}' "
                f"'http://127.0.0.1{path}'",
            )
            _, body, _ = run(c, "head -c 280 /tmp/ba2.json")
            checks.append({"path": path, "http": http.strip(), "body": body})
            print(path, http.strip(), body[:200])
        print(json.dumps(checks, ensure_ascii=False, indent=2)[:3000])
    finally:
        sftp.close()
        c.close()


if __name__ == "__main__":
    main()
