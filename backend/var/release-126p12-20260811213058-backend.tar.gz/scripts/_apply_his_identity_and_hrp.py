"""1) Apply HIS identity to platform PG (dry_run=false). 2) Probe HRP + WA_ field harvest.

Source Oracle: SELECT only. Platform PG: identity upserts allowed by user approval.
"""
from __future__ import annotations

import json
import os
import textwrap

import paramiko

HOST = "10.10.8.83"
PASSWORD = os.environ.get("APP_SSH_PASSWORD", "P@ssw0rd@123")
ROOT = r"F:\python\数据资产\backend"


def run(c, cmd, timeout=600):
    _i, o, e = c.exec_command(cmd, timeout=timeout)
    code = o.channel.recv_exit_status()
    return code, o.read().decode("utf-8", "replace"), e.read().decode("utf-8", "replace")


APPLY_PY = textwrap.dedent(
    """\
    import json
    from datetime import datetime, timezone
    from pathlib import Path

    from app.core.db import SessionLocal
    from app.core.config import settings
    from app.services.his_identity_sync import sync_his_identity, EMPLOYEE_TABLE
    from sqlalchemy import text

    his_user, his_pwd = Path("/etc/data-asset/credentials/his_source_10_10_10_15").read_text().strip().split(":", 1)
    settings.his_source_host = "10.10.10.15"
    settings.his_source_port = 1521
    settings.his_source_service = "his"
    settings.his_source_user = his_user
    settings.his_source_password = his_pwd
    settings.his_source_connection_mode = "direct"
    settings.his_source_oracle_client_lib = "/opt/oracle"

    db = SessionLocal()
    out = {"employee_table": EMPLOYEE_TABLE, "started_at": datetime.now(timezone.utc).isoformat()}
    try:
        # counts before
        before = {}
        for t in [
            "asset_identity_persons",
            "asset_identity_departments",
            "asset_identity_person_sources",
            "asset_identity_person_departments",
        ]:
            before[t] = db.execute(text(f"SELECT COUNT(*) FROM asset.{t}")).scalar()
        out["before"] = before

        result = sync_his_identity(
            db,
            operator="user_approved_platform_admin",
            dry_run=False,
            max_rows=20000,
            write_audit=True,
        )
        out["apply"] = result

        after = {}
        for t in [
            "asset_identity_persons",
            "asset_identity_departments",
            "asset_identity_person_sources",
            "asset_identity_person_departments",
        ]:
            after[t] = db.execute(text(f"SELECT COUNT(*) FROM asset.{t}")).scalar()
        out["after"] = after

        # sample non-PHI stats
        out["sample_stats"] = {
            "persons_active": db.execute(
                text("SELECT COUNT(*) FROM asset.asset_identity_persons WHERE employment_status='active'")
            ).scalar(),
            "persons_with_dept": db.execute(
                text("SELECT COUNT(*) FROM asset.asset_identity_persons WHERE dept_code IS NOT NULL AND dept_code<>''")
            ).scalar(),
            "audit_rows": db.execute(
                text(
                    "SELECT COUNT(*) FROM asset.asset_govern_audit_log "
                    "WHERE module='sync' AND entity_ref='his_source_10_10_10_15'"
                )
            ).scalar(),
        }
        out["status"] = "success"
    except Exception as ex:
        db.rollback()
        out["status"] = "error"
        out["error"] = f"{type(ex).__name__}:{str(ex)[:500]}"
        raise
    finally:
        db.close()
        out["finished_at"] = datetime.now(timezone.utc).isoformat()
        print(json.dumps(out, ensure_ascii=False, indent=2, default=str))
    """
)

HRP_PROBE_PY = textwrap.dedent(
    """\
    import json, os, time
    from pathlib import Path
    import oracledb

    oracledb.init_oracle_client(lib_dir="/opt/oracle")

    def try_connect(label, user, password, dsn):
        t0 = time.time()
        try:
            conn = oracledb.connect(user=user, password=password, dsn=dsn)
            cur = conn.cursor()
            try:
                cur.execute("SET TRANSACTION READ ONLY")
            except Exception:
                pass
            cur.execute("SELECT USER, SYS_CONTEXT('USERENV','DB_NAME') FROM dual")
            who = cur.fetchone()
            cur.execute("SELECT banner FROM v$version WHERE ROWNUM<=1")
            banner = cur.fetchone()
            cur.close(); conn.close()
            return {"label": label, "ok": True, "ms": round((time.time()-t0)*1000,1),
                    "user": who[0], "db": who[1], "banner": (banner[0][:80] if banner else None)}
        except Exception as ex:
            return {"label": label, "ok": False, "ms": round((time.time()-t0)*1000,1),
                    "error": f"{type(ex).__name__}:{str(ex)[:180]}"}

    cands = []
    # env file credentials
    for path, label in [
        ("/etc/data-asset/credentials/hrp_10_10_10_23", "file_hrp"),
        ("/etc/data-asset/credentials/hrp", "file_hrp2"),
    ]:
        p = Path(path)
        if p.exists():
            raw = p.read_text().strip()
            if ":" in raw:
                u, pw = raw.split(":", 1)
                cands.append((label, u, pw, "10.10.10.23:1521/hrpdb"))

    for env_name, label in [("CRED_HRP", "env_CRED_HRP"), ("HRP_USER_PASS", "env_HRP_USER_PASS")]:
        raw = os.environ.get(env_name, "")
        if raw and ":" in raw:
            u, pw = raw.split(":", 1)
            cands.append((label, u, pw, "10.10.10.23:1521/hrpdb"))

    # historical common readonly-style names if provided via env injection
    if os.environ.get("HRP_PASSWORD"):
        cands.append((
            "env_HRP_PASSWORD",
            os.environ.get("HRP_USER", "hrp"),
            os.environ["HRP_PASSWORD"],
            "10.10.10.23:1521/hrpdb",
        ))

    # try a few historical candidates carefully (no print of password)
    for u, pw in [
        (os.environ.get("TRY_HRP_USER", ""), os.environ.get("TRY_HRP_PASSWORD", "")),
    ]:
        if u and pw:
            cands.append(("try_env", u, pw, "10.10.10.23:1521/hrpdb"))

    print(json.dumps({
        "candidate_labels": [x[0] for x in cands],
        "results": [try_connect(l, u, p, d) for l, u, p, d in cands],
    }, ensure_ascii=False, indent=2))
    """
)

WA_HARVEST_PY = textwrap.dedent(
    """\
    import json
    from pathlib import Path
    import oracledb

    oracledb.init_oracle_client(lib_dir="/opt/oracle")
    raw = Path("/etc/data-asset/credentials/hrp_10_10_10_23").read_text().strip()
    if ":" not in raw:
        raise SystemExit("missing hrp credential file")
    user, password = raw.split(":", 1)
    conn = oracledb.connect(user=user, password=password, dsn="10.10.10.23:1521/hrpdb")
    cur = conn.cursor()
    try:
        cur.execute("SET TRANSACTION READ ONLY")
    except Exception:
        pass

    core = [
        "WA_DATA", "WA_PSNTAX", "WA_CLASSITEM", "WA_ITEMPOWER",
        "WA_WACLASS", "WA_PSNHI_B", "WA_ITEM", "WA_PSNHI",
        "BD_PSNDOC", "HI_PSNJOB", "ORG_DEPT", "SM_USER",
    ]
    out = {"tables": {}, "wa_columns": [], "core_columns": [], "owners_with_wa": []}

    cur.execute(
        "SELECT owner, table_name, NVL(num_rows,0) FROM all_tables "
        "WHERE table_name LIKE 'WA_%' ORDER BY owner, table_name"
    )
    out["wa_tables"] = [{"owner": r[0], "table": r[1], "num_rows": r[2]} for r in cur.fetchall()]

    cur.execute(
        "SELECT DISTINCT owner FROM all_tables WHERE table_name LIKE 'WA_%' ORDER BY 1"
    )
    out["owners_with_wa"] = [r[0] for r in cur.fetchall()]

    # columns for WA_% (the gap from 52)
    cur.execute(
        "SELECT owner, table_name, column_name, data_type, data_length, nullable, column_id "
        "FROM all_tab_columns WHERE table_name LIKE 'WA_%' "
        "ORDER BY owner, table_name, column_id"
    )
    for r in cur.fetchall():
        out["wa_columns"].append({
            "owner": r[0], "table_name": r[1], "column_name": r[2],
            "data_type": r[3], "data_length": r[4], "nullable": r[5], "column_id": r[6],
        })

    # core HR identity tables columns
    for tname in core:
        cur.execute(
            "SELECT owner, table_name FROM all_tables WHERE table_name=:t ORDER BY owner",
            t=tname,
        )
        owners = cur.fetchall()
        out["tables"][tname] = [{"owner": o, "table": tb} for o, tb in owners]
        for o, tb in owners:
            cur.execute(
                "SELECT column_name, data_type, data_length, nullable, column_id "
                "FROM all_tab_columns WHERE owner=:o AND table_name=:t ORDER BY column_id",
                o=o, t=tb,
            )
            for r in cur.fetchall():
                out["core_columns"].append({
                    "owner": o, "table_name": tb, "column_name": r[0],
                    "data_type": r[1], "data_length": r[2], "nullable": r[3], "column_id": r[4],
                })
            try:
                cur.execute(f"SELECT COUNT(*) FROM {o}.{tb} WHERE ROWNUM<=1")
                has = cur.fetchone()[0]
            except Exception as ex:
                has = f"ERR:{type(ex).__name__}"
            out["tables"][tname].append({"probe_owner": o, "has_row": has})

    cur.close(); conn.close()
    print(json.dumps({
        "wa_table_count": len(out["wa_tables"]),
        "wa_column_count": len(out["wa_columns"]),
        "core_column_count": len(out["core_columns"]),
        "owners_with_wa": out["owners_with_wa"],
        "wa_tables_sample": out["wa_tables"][:30],
        "tables": out["tables"],
        "wa_columns": out["wa_columns"],
        "core_columns": out["core_columns"],
    }, ensure_ascii=False))
    """
)


def main() -> None:
    c = paramiko.SSHClient()
    c.set_missing_host_key_policy(paramiko.AutoAddPolicy())
    c.connect(HOST, username="root", password=PASSWORD, timeout=15, allow_agent=False, look_for_keys=False)

    sftp = c.open_sftp()
    sftp.put(os.path.join(ROOT, r"app\services\his_identity_sync.py"), "/tmp/his_identity_sync.py")
    with sftp.file("/tmp/apply_his_identity.py", "w") as f:
        f.write(APPLY_PY)
    with sftp.file("/tmp/hrp_probe.py", "w") as f:
        f.write(HRP_PROBE_PY)
    with sftp.file("/tmp/hrp_wa_harvest.py", "w") as f:
        f.write(WA_HARVEST_PY)
    sftp.close()

    print("=== prep runtime + sync code")
    code, out, err = run(
        c,
        "bash /etc/data-asset/ensure_oracle_ro_runtime.sh; "
        "docker cp /tmp/his_identity_sync.py data-asset-api:/app/app/services/his_identity_sync.py; "
        "docker cp /tmp/apply_his_identity.py data-asset-api:/tmp/apply_his_identity.py; "
        "docker cp /tmp/hrp_probe.py data-asset-api:/tmp/hrp_probe.py; "
        "docker cp /tmp/hrp_wa_harvest.py data-asset-api:/tmp/hrp_wa_harvest.py",
        timeout=60,
    )
    print(out[:1500], err[:300] if err else "")

    print("=== 1) APPLY HIS identity (platform write)")
    code, out, err = run(
        c,
        "docker exec -e PYTHONPATH=/app data-asset-api python /tmp/apply_his_identity.py",
        timeout=300,
    )
    print("exit", code)
    print(out[:12000])
    if err:
        print("ERR", err[:2000])
    apply_out = out

    print("=== network HRP")
    code, out, err = run(
        c,
        "timeout 3 bash -c 'echo >/dev/tcp/10.10.10.23/1521' && echo HRP_OPEN || echo HRP_CLOSED; "
        "ls -la /etc/data-asset/credentials/; "
        "ls /home/med-audit_ai_mr 2>/dev/null | head",
        timeout=30,
    )
    print(out)

    # look for historical hrp password files without printing secrets
    code, out, err = run(
        c,
        "find /etc /root /opt /home -type f \\( -iname '*hrp*' -o -iname '*credential*' \\) 2>/dev/null | head -40; "
        "env | cut -d= -f1 | grep -iE 'HRP|CRED' || true",
        timeout=60,
    )
    print("=== search credential paths")
    print(out[:3000])

    # Try common historical HRP accounts via process env only (document-derived defaults)
    # Will not print passwords. If unknown, probe will show empty candidates.
    inject = (
        "export CRED_HRP=${CRED_HRP:-}; "
        "export HRP_USER=${HRP_USER:-}; "
        "export HRP_PASSWORD=${HRP_PASSWORD:-}; "
        # common NC readonly style if present on host files
        "if [ -f /etc/data-asset/credentials/hrp_10_10_10_23 ]; then true; "
        "elif [ -f /root/.hrp_cred ]; then cp /root/.hrp_cred /etc/data-asset/credentials/hrp_10_10_10_23; fi; "
        "true"
    )
    code, out, err = run(
        c,
        f"{inject} docker exec -e CRED_HRP -e HRP_USER -e HRP_PASSWORD -e TRY_HRP_USER -e TRY_HRP_PASSWORD "
        f"data-asset-api python /tmp/hrp_probe.py",
        timeout=90,
    )
    print("=== HRP probe")
    print(out[:4000])
    if err:
        print("ERR", err[:1000])

    c.close()
    # save apply result locally path note
    Path_out = os.path.join(ROOT, "scripts", "_apply_his_identity_result.json")
    try:
        # extract json from apply_out
        start = apply_out.find("{")
        end = apply_out.rfind("}")
        if start >= 0 and end > start:
            with open(Path_out, "w", encoding="utf-8") as f:
                f.write(apply_out[start : end + 1])
            print("saved", Path_out)
    except Exception as ex:
        print("save local failed", ex)


if __name__ == "__main__":
    main()
