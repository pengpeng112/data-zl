"""Retry identity apply after unique-key fix; search HRP credentials safely."""
from __future__ import annotations

import os
import textwrap

import paramiko

HOST = "10.10.8.83"
PASSWORD = os.environ.get("APP_SSH_PASSWORD", "P@ssw0rd@123")
ROOT = r"F:\python\数据资产\backend"


def run(c, cmd, timeout=600):
    _i, o, e = c.exec_command(cmd, timeout=timeout)
    return o.channel.recv_exit_status(), o.read().decode("utf-8", "replace"), e.read().decode("utf-8", "replace")


APPLY = textwrap.dedent(
    """\
    import json
    from datetime import datetime, timezone
    from pathlib import Path
    from app.core.db import SessionLocal
    from app.core.config import settings
    from app.services.his_identity_sync import sync_his_identity, EMPLOYEE_TABLE
    from sqlalchemy import text

    his_user, his_pwd = Path("/etc/data-asset/credentials/his_source_10_10_10_15").read_text().strip().split(":", 1)
    settings.his_source_host = "10.10.10.15"
    settings.his_source_port = 1521
    settings.his_source_service = "his"
    settings.his_source_user = his_user
    settings.his_source_password = his_pwd
    settings.his_source_connection_mode = "direct"
    settings.his_source_oracle_client_lib = "/opt/oracle"

    db = SessionLocal()
    out = {"employee_table": EMPLOYEE_TABLE}
    try:
        before = {
            t: db.execute(text(f"SELECT COUNT(*) FROM asset.{t}")).scalar()
            for t in [
                "asset_identity_persons",
                "asset_identity_departments",
                "asset_identity_person_sources",
                "asset_identity_person_departments",
            ]
        }
        out["before"] = before
        result = sync_his_identity(
            db, operator="user_approved_platform_admin", dry_run=False, max_rows=20000, write_audit=True
        )
        out["apply"] = {
            "status": result.get("status"),
            "mode": result.get("mode"),
            "dry_run": result.get("dry_run"),
            "scanned": result.get("scanned"),
            "prepared": result.get("prepared"),
            "bridge": result.get("bridge"),
            "upserted": result.get("upserted"),
            "doctor_group_diagnostics": result.get("doctor_group_diagnostics"),
            "finished_at": result.get("finished_at"),
        }
        after = {
            t: db.execute(text(f"SELECT COUNT(*) FROM asset.{t}")).scalar()
            for t in [
                "asset_identity_persons",
                "asset_identity_departments",
                "asset_identity_person_sources",
                "asset_identity_person_departments",
            ]
        }
        out["after"] = after
        out["status"] = "success"
    except Exception as ex:
        db.rollback()
        out["status"] = "error"
        out["error"] = f"{type(ex).__name__}:{str(ex)[:400]}"
    finally:
        db.close()
        out["finished_at"] = datetime.now(timezone.utc).isoformat()
        print(json.dumps(out, ensure_ascii=False, indent=2, default=str))
    """
)


def main() -> None:
    c = paramiko.SSHClient()
    c.set_missing_host_key_policy(paramiko.AutoAddPolicy())
    c.connect(HOST, username="root", password=PASSWORD, timeout=15, allow_agent=False, look_for_keys=False)

    sftp = c.open_sftp()
    sftp.put(os.path.join(ROOT, r"app\services\his_identity_sync.py"), "/tmp/his_identity_sync.py")
    with sftp.file("/tmp/apply_his_identity2.py", "w") as f:
        f.write(APPLY)
    sftp.close()

    code, out, err = run(
        c,
        "bash /etc/data-asset/ensure_oracle_ro_runtime.sh >/dev/null; "
        "docker cp /tmp/his_identity_sync.py data-asset-api:/app/app/services/his_identity_sync.py; "
        "docker cp /tmp/apply_his_identity2.py data-asset-api:/tmp/apply_his_identity2.py; "
        "docker exec -e PYTHONPATH=/app data-asset-api python /tmp/apply_his_identity2.py",
        timeout=300,
    )
    print("=== apply exit", code)
    print(out[:10000])
    if err:
        print("ERR", err[:1500])

    # Search HRP passwords in known project locations without printing secret values
    code, out, err = run(
        c,
        r"""
set +e
echo '=== file name hits'
find /home /opt /root /etc /var -type f 2>/dev/null | grep -iE 'hrp|hrpdb|nc.*cred|credential' | head -50
echo '=== compose/env key names'
grep -RIl --include='*.env' --include='*.yml' --include='*.yaml' --include='*.sh' --include='*.py' -E 'HRP_|hrpdb|10\.10\.10\.23' /opt /home /root 2>/dev/null | head -40
echo '=== extract non-secret keys near HRP'
for f in $(grep -RIl --include='*.env' --include='*.yml' --include='*.sh' -E 'HRP_|10\.10\.10\.23' /opt /home /root /etc 2>/dev/null | head -20); do
  echo "FILE $f"
  grep -nE 'HRP_|10\.10\.10\.23|hrpdb' "$f" 2>/dev/null | sed -E 's/(PASSWORD|PWD|SECRET|TOKEN)=.*/\1=***/I' | head -20
done
echo '=== jump 8.53 files?'
timeout 2 bash -c 'echo >/dev/tcp/10.10.8.53/40022' && echo JUMP_OPEN || echo JUMP_CLOSED
""",
        timeout=120,
    )
    print(out[:8000])
    c.close()


if __name__ == "__main__":
    main()
