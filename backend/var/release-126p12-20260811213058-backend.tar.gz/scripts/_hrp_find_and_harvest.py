"""Find HRP credentials via jump/host; harvest WA_ fields read-only if possible.

Also try ODS.HRP schema as fallback for field presence.
"""
from __future__ import annotations

import json
import os
import textwrap

import paramiko

HOST = "10.10.8.83"
PASSWORD = os.environ.get("APP_SSH_PASSWORD", "P@ssw0rd@123")


def run(c, cmd, timeout=300):
    _i, o, e = c.exec_command(cmd, timeout=timeout)
    return o.channel.recv_exit_status(), o.read().decode("utf-8", "replace"), e.read().decode("utf-8", "replace")


def main() -> None:
    c = paramiko.SSHClient()
    c.set_missing_host_key_policy(paramiko.AutoAddPolicy())
    c.connect(HOST, username="root", password=PASSWORD, timeout=15, allow_agent=False, look_for_keys=False)

    # 1) search jump host for HRP env without printing secrets
    code, out, err = run(
        c,
        r"""
set +e
# try common jump auth: key first then passwordless
for key in /root/.ssh/id_ed25519_ai /root/.ssh/id_rsa /root/.ssh/id_ed25519; do
  if [ -f "$key" ]; then echo HAS_KEY $key; fi
done
ls -la /root/.ssh 2>/dev/null | head -20
# probe jump with BatchMode
ssh -p 40022 -o BatchMode=yes -o ConnectTimeout=5 -o StrictHostKeyChecking=no root@10.10.8.53 'echo JUMP_OK; ls /opt/oracle 2>/dev/null | head; env | cut -d= -f1 | grep -iE "HRP|ORACLE|ODS" || true; ls /etc/data-asset/credentials 2>/dev/null; ls /home 2>/dev/null | head; find /root /home /opt/data-asset -maxdepth 3 -type f 2>/dev/null | grep -iE "hrp|cred|\.env" | head -30' 2>&1 | head -80
""",
        timeout=60,
    )
    print("=== jump probe")
    print(out[:5000])
    if err:
        print("ERR", err[:500])

    # 2) ODS side: any WA_ or BD_PSNDOC under HRP owner?
    ods_py = textwrap.dedent(
        """\
        import json
        from pathlib import Path
        import oracledb
        oracledb.init_oracle_client(lib_dir="/opt/oracle")
        u,p = Path("/etc/data-asset/credentials/ods_8_216").read_text().strip().split(":",1)
        conn=oracledb.connect(user=u,password=p,dsn="10.10.8.216:1521/orcl")
        cur=conn.cursor()
        try:
            cur.execute("SET TRANSACTION READ ONLY")
        except Exception:
            pass
        out={}
        cur.execute("SELECT table_name, NVL(num_rows,0) FROM all_tables WHERE owner='HRP' ORDER BY table_name")
        out["ods_hrp_tables"]=[{"table":r[0],"num_rows":r[1]} for r in cur.fetchall()]
        cur.execute("SELECT table_name FROM all_tables WHERE owner='HRP' AND (table_name LIKE 'WA_%' OR table_name LIKE 'BD_PSN%' OR table_name LIKE 'HI_%' OR table_name LIKE 'ORG_%') ORDER BY 1")
        out["ods_hrp_person_like"]=[r[0] for r in cur.fetchall()]
        # columns for those if any
        cols=[]
        for t in out["ods_hrp_person_like"][:20]:
            cur.execute("SELECT column_name, data_type, data_length, nullable FROM all_tab_columns WHERE owner='HRP' AND table_name=:t ORDER BY column_id", t=t)
            for r in cur.fetchall():
                cols.append({"table":t,"column":r[0],"type":r[1],"len":r[2],"null":r[3]})
        out["ods_hrp_person_cols"]=cols
        print(json.dumps(out, ensure_ascii=False, indent=2))
        cur.close(); conn.close()
        """
    )
    sftp = c.open_sftp()
    with sftp.file("/tmp/ods_hrp_probe.py", "w") as f:
        f.write(ods_py)
    sftp.close()
    code, out, err = run(
        c,
        "bash /etc/data-asset/ensure_oracle_ro_runtime.sh >/dev/null; "
        "docker cp /tmp/ods_hrp_probe.py data-asset-api:/tmp/ods_hrp_probe.py; "
        "docker exec data-asset-api python /tmp/ods_hrp_probe.py",
        timeout=120,
    )
    print("=== ODS HRP schema")
    print(out[:8000])
    if err:
        print("ERR", err[:800])

    # 3) try historical HRP accounts from common NC patterns via env if user set nothing
    # Document said env HRP_USER/HRP_PASSWORD - check bash history carefully for var NAMES only
    code, out, err = run(
        c,
        r"""
set +e
echo '=== history names only'
grep -hE 'HRP_|hrpdb|10\.10\.10\.23' /root/.bash_history /home/*/.bash_history 2>/dev/null | sed -E 's/(PASSWORD|PWD|passwd)[=:].*/\1=***/I' | tail -40
echo '=== docker env files'
find /home/med-audit_ai_mr /opt -type f \( -name '*.env' -o -name '*secret*' -o -name '*cred*' \) 2>/dev/null | head -40
for f in $(find /home/med-audit_ai_mr /opt -type f -name '*.env' 2>/dev/null | head -30); do
  if grep -qiE 'HRP|10\.10\.10\.23' "$f" 2>/dev/null; then
    echo FILE $f
    grep -nE 'HRP|10\.10\.10\.23' "$f" | sed -E 's/(PASSWORD|PWD|SECRET)=.*/\1=***/I'
  fi
done
""",
        timeout=60,
    )
    print(out[:6000])

    c.close()


if __name__ == "__main__":
    main()
