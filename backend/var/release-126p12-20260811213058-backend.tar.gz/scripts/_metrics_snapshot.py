from sqlalchemy import text
from app.core.db import SessionLocal

db = SessionLocal()
try:
    def q(sql):
        return db.execute(text(sql)).fetchall()

    print("systems", q("select status, count(*) from asset.asset_systems group by 1 order by 1"))
    print("sources_policy", q("select coalesce(write_policy,'readonly'), count(*) from asset.asset_data_sources group by 1"))
    print("sources_enabled", q("select enabled, count(*) from asset.asset_data_sources group by 1"))
    print("tables", q("select count(*) from asset.asset_tables")[0][0])
    print("columns", q("select count(*) from asset.asset_columns")[0][0])
    print("relations", q("select count(*) from asset.asset_relations")[0][0])
    print("tables_by_system", q("select system_code, count(*) from asset.asset_tables group by 1 order by 2 desc"))
    print("dict_items", q("select code_set_code, count(*) from asset.asset_dict_medical_code_items group by 1 order by 1"))
    print("dict_maps", q("select category_code, count(*) from asset.asset_dict_medical_code_mappings group by 1"))
    try:
        print("identity_person", q("select count(*) from asset.asset_identity_persons")[0][0])
    except Exception as e:
        print("identity_person_err", type(e).__name__)
    try:
        print("identity_dept", q("select count(*) from asset.asset_identity_departments")[0][0])
    except Exception as e:
        print("identity_dept_err", type(e).__name__)
    try:
        print("quality_runs", q("select count(*) from asset.asset_quality_runs")[0][0])
    except Exception as e:
        print("quality_runs_err", type(e).__name__)
    try:
        print("recipes", q("select count(*) from asset.asset_relation_recipes")[0][0])
    except Exception as e:
        print("recipes_err", type(e).__name__)
    try:
        print("auth_users", q("select count(*) from asset.asset_auth_users")[0][0])
    except Exception as e:
        print("auth_users_err", type(e).__name__)
finally:
    db.close()
