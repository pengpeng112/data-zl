"""Hot-sync backend/frontend to 8.83 and import normalized package into platform PG.

Requires network to 10.10.8.83. Uses APP_SSH_PASSWORD if set.
Does NOT touch HIS/ODS/HRP write paths.
"""
from __future__ import annotations

import os
import sys
import tarfile
import tempfile
import time
from pathlib import Path

import paramiko

ROOT = Path(__file__).resolve().parents[2]
BACKEND = ROOT / "backend"
FRONTEND_DIST = ROOT / "frontend" / "dist"
CSV_DIR = ROOT / "开发起步包" / "数据资产_ODS_HIS归一优化包"

HOST = os.environ.get("APP_SSH_HOST", "10.10.8.83")
USER = os.environ.get("APP_SSH_USER", "root")
PASSWORD = os.environ.get("APP_SSH_PASSWORD", "P@ssw0rd@123")
CONTAINER = os.environ.get("APP_DOCKER_CONTAINER", "data-asset-api")


def run(client: paramiko.SSHClient, cmd: str, timeout: int = 900) -> tuple[int, str, str]:
    _i, o, e = client.exec_command(cmd, timeout=timeout)
    out = o.read().decode("utf-8", "replace")
    err = e.read().decode("utf-8", "replace")
    return o.channel.recv_exit_status(), out, err


def make_backend_tar() -> Path:
    ignore_dirs = {".venv", "__pycache__", ".pytest_cache", "logs", "data", ".mypy_cache", "htmlcov", ".ruff_cache"}
    ignore_prefixes = ("_tmp", "_deploy", "_run", "_sync", "_ufe", "_v", "_chk", "_ready", "_hotfix", "_audit", "_ro_")
    fd, name = tempfile.mkstemp(suffix="-backend-sync.tar.gz")
    os.close(fd)
    out = Path(name)
    with tarfile.open(out, "w:gz") as tar:
        for path in BACKEND.rglob("*"):
            if not path.is_file():
                continue
            if any(p in ignore_dirs for p in path.parts):
                continue
            if path.suffix == ".pyc":
                continue
            if path.name.startswith(ignore_prefixes):
                continue
            arc = f"backend/{path.relative_to(BACKEND).as_posix()}"
            tar.add(path, arcname=arc)
    return out


def make_csv_tar() -> Path:
    fd, name = tempfile.mkstemp(suffix="-normalized-csv.tar.gz")
    os.close(fd)
    out = Path(name)
    with tarfile.open(out, "w:gz") as tar:
        for name_f in (
            "normalized_tables.csv",
            "normalized_columns.csv",
            "normalized_relationships.csv",
            "normalized_catalog.json",
        ):
            p = CSV_DIR / name_f
            if p.exists():
                tar.add(p, arcname=f"normalized/{name_f}")
    return out


def sftp_mkdirs(sftp: paramiko.SFTPClient, path: str) -> None:
    parts = path.strip("/").split("/")
    cur = ""
    for p in parts:
        cur += "/" + p
        try:
            sftp.stat(cur)
        except FileNotFoundError:
            sftp.mkdir(cur)


def put_tree(sftp: paramiko.SFTPClient, local: Path, remote: str) -> int:
    n = 0
    sftp_mkdirs(sftp, remote)
    for root, _dirs, files in os.walk(local):
        rel = os.path.relpath(root, local).replace("\\", "/")
        rdir = remote if rel == "." else f"{remote}/{rel}"
        sftp_mkdirs(sftp, rdir)
        for f in files:
            sftp.put(str(Path(root) / f), f"{rdir}/{f}")
            n += 1
    return n


def main() -> int:
    if not FRONTEND_DIST.exists():
        print("frontend/dist missing; run pnpm build first", file=sys.stderr)
        return 1
    if not (CSV_DIR / "normalized_tables.csv").exists():
        print(f"missing CSV in {CSV_DIR}", file=sys.stderr)
        return 1

    stamp = time.strftime("%Y%m%d%H%M%S")
    remote_rel = f"/opt/data-asset/releases/sync-{stamp}"

    client = paramiko.SSHClient()
    client.set_missing_host_key_policy(paramiko.AutoAddPolicy())
    client.connect(HOST, username=USER, password=PASSWORD, timeout=20, allow_agent=False, look_for_keys=False)
    sftp = client.open_sftp()
    try:
        sftp_mkdirs(sftp, remote_rel)

        print("== pack backend ==")
        btar = make_backend_tar()
        remote_btar = f"{remote_rel}/backend.tar.gz"
        sftp.put(str(btar), remote_btar)
        btar.unlink(missing_ok=True)

        print("== unpack backend into container ==")
        code, out, err = run(
            client,
            f"mkdir -p {remote_rel}/backend_src; tar -xzf {remote_btar} -C {remote_rel}/backend_src; "
            f"docker cp {remote_rel}/backend_src/backend/. {CONTAINER}:/app/; "
            f"docker restart {CONTAINER}",
            timeout=180,
        )
        print(out or err)
        if code != 0:
            print("backend deploy failed", code, err)
            return code

        print("== wait api ==")
        time.sleep(8)
        code, out, err = run(client, f"docker ps --filter name={CONTAINER} --format '{{{{.Status}}}}'")
        print("container:", out.strip() or err)

        print("== frontend dist ==")
        fe_remote = f"{remote_rel}/frontend_dist"
        n = put_tree(sftp, FRONTEND_DIST, fe_remote)
        print(f"uploaded {n} frontend files")
        # common nginx path used previously
        for target in ("/usr/share/nginx/html", "/var/www/html", "/opt/data-asset/frontend/dist"):
            code, out, err = run(client, f"test -d {target} && echo EXISTS:{target} || true")
            if "EXISTS" in out:
                run(client, f"rsync -a --delete {fe_remote}/ {target}/ 2>/dev/null || cp -a {fe_remote}/. {target}/")
                print("synced frontend to", target)
        # reload nginx if present
        run(client, "nginx -s reload 2>/dev/null || systemctl reload nginx 2>/dev/null || true")

        print("== upload normalized csv ==")
        ctar = make_csv_tar()
        remote_ctar = f"{remote_rel}/normalized.tar.gz"
        sftp.put(str(ctar), remote_ctar)
        ctar.unlink(missing_ok=True)
        run(
            client,
            f"mkdir -p /tmp/normalized_pkg; tar -xzf {remote_ctar} -C /tmp; "
            f"docker cp /tmp/normalized {CONTAINER}:/tmp/normalized; "
            f"docker cp {remote_rel}/backend_src/backend/scripts/import_normalized_to_platform.py "
            f"{CONTAINER}:/app/scripts/import_normalized_to_platform.py",
        )

        print("== import normalized package ==")
        code, out, err = run(
            client,
            f"docker exec {CONTAINER} bash -lc "
            f"'cd /app && PYTHONPATH=/app python scripts/import_normalized_to_platform.py "
            f"--csv-dir /tmp/normalized --force --columns-limit 80000'",
            timeout=600,
        )
        print("import exit", code)
        print(out)
        if err:
            print("stderr:", err[:2000])

        print("== verify counts ==")
        code, out, err = run(
            client,
            f"docker exec {CONTAINER} bash -lc "
            "\"python - <<'PY'\n"
            "from app.core.db import SessionLocal\n"
            "from sqlalchemy import text\n"
            "db=SessionLocal()\n"
            "for t in ['asset_tables','asset_columns','asset_relations','asset_systems','asset_data_sources']:\n"
            "    n=db.execute(text(f'select count(*) from asset.{{t}}')).scalar()\n"
            "    print(t, n)\n"
            "db.close()\n"
            "PY\"",
        )
        print(out or err)

        print("== smoke dashboard ==")
        code, out, err = run(
            client,
            "curl -sS -o /tmp/dash.json -w '%{http_code}' http://127.0.0.1:8000/api/v1/dashboard/summary || "
            "curl -sS -o /tmp/dash.json -w '%{http_code}' http://127.0.0.1:8080/api/v1/dashboard/summary || true",
        )
        print("http", out)
        run(client, "head -c 400 /tmp/dash.json 2>/dev/null; echo")
        return 0
    finally:
        sftp.close()
        client.close()


if __name__ == "__main__":
    raise SystemExit(main())
