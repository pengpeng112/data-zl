import oracledb, os
try: oracledb.init_oracle_client(lib_dir="/opt/oracle")
except Exception: pass
conn = oracledb.connect(user=os.environ["ODS_8_216_USER"], password=os.environ["ODS_8_216_PASSWORD"], dsn="10.10.8.216:1521/orcl")
conn.call_timeout = 30000
cur = conn.cursor()
cur.execute("SET TRANSACTION READ ONLY")
def run(label, sql):
    try:
        cur.execute(sql)
        rows = cur.fetchmany(25)
        print(f"=== {label} ===")
        for r in rows: print("  ", r)
        if not rows: print("  (无数据)")
    except Exception as e:
        print(f"=== {label} ERR: {str(e)[:120]}")

run("住院0502任意时间", "SELECT count(*) FROM HIS.LAB_TEST_MASTER WHERE VISIT_ID>0 AND PERFORMED_BY='0502'")
run("门诊0502 ITEM_CLASS=C", "SELECT count(*) FROM HIS.OUTP_TREAT_REC WHERE ITEM_CLASS='C' AND PERFORMED_BY='0502'")
run("门诊0502 前缀(6月)", """SELECT substr(ITEM_NAME,1,2) pfx, count(*) FROM HIS.OUTP_TREAT_REC
WHERE VISIT_DATE>=ADD_MONTHS(SYSDATE,-6) AND ITEM_CLASS='C' AND PERFORMED_BY='0502'
GROUP BY substr(ITEM_NAME,1,2) ORDER BY 2 DESC""")
run("住院 performed_by 分布(近1月)", """SELECT PERFORMED_BY,count(*) FROM HIS.LAB_TEST_MASTER
WHERE REQUESTED_DATE_TIME>=ADD_MONTHS(SYSDATE,-1) AND VISIT_ID>0 GROUP BY PERFORMED_BY ORDER BY 2 DESC""")
run("DT/DP/WK/BR 样本(全表)", "SELECT DISTINCT ITEM_NAME FROM HIS.LAB_TEST_ITEMS WHERE ITEM_NAME LIKE 'DT%' OR ITEM_NAME LIKE 'DP%' OR ITEM_NAME LIKE 'WK%' OR ITEM_NAME LIKE 'BR%' AND ROWNUM<=10")
run("WS 样本(全表)", "SELECT DISTINCT ITEM_CODE,ITEM_NAME FROM HIS.LAB_TEST_ITEMS WHERE ITEM_CODE LIKE 'WS%' AND ROWNUM<=10")
cur.close(); conn.close()
