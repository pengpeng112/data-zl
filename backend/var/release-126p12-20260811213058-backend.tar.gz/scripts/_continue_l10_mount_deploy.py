"""Continue work: seed quality job if missing, upload 08+diff script, run L10-diff,
hot-sync identity.py and frontend, install ensure_oracle script on host.
"""
from __future__ import annotations

import io
import os
import tarfile
import tempfile
import time
from pathlib import Path

import paramiko

ROOT = Path(__file__).resolve().parents[2]
HOST = os.environ.get("APP_SSH_HOST", "10.10.8.83")
PASSWORD = os.environ.get("APP_SSH_PASSWORD", "P@ssw0rd@123")
CONTAINER = "data-asset-api"


def run(c, cmd, timeout=600):
    _, o, e = c.exec_command(cmd, timeout=timeout)
    return o.channel.recv_exit_status(), o.read().decode("utf-8", "replace"), e.read().decode("utf-8", "replace")


def main():
    c = paramiko.SSHClient()
    c.set_missing_host_key_policy(paramiko.AutoAddPolicy())
    c.connect(HOST, username="root", password=PASSWORD, timeout=20, allow_agent=False, look_for_keys=False)
    sftp = c.open_sftp()
    try:
        # 1) hot copy identity + quality scripts into container
        files = {
            str(ROOT / "backend/app/api/v1/identity.py"): "/tmp/identity.py",
            str(ROOT / "backend/scripts/diff_live_snapshot_vs_08.py"): "/tmp/diff_live_snapshot_vs_08.py",
            str(ROOT / "deploy/scripts/ensure_oracle_ro_runtime.sh"): "/tmp/ensure_oracle_ro_runtime.sh",
            str(ROOT / "deploy/scripts/run_data_asset_api.sh"): "/tmp/run_data_asset_api.sh",
        }
        for local, remote in files.items():
            sftp.put(local, remote)
            print("put", remote)

        cmds = [
            f"docker cp /tmp/identity.py {CONTAINER}:/app/app/api/v1/identity.py",
            f"docker cp /tmp/diff_live_snapshot_vs_08.py {CONTAINER}:/app/scripts/diff_live_snapshot_vs_08.py",
            "mkdir -p /etc/data-asset/scripts /etc/data-asset/credentials",
            "cp /tmp/ensure_oracle_ro_runtime.sh /etc/data-asset/scripts/; chmod +x /etc/data-asset/scripts/ensure_oracle_ro_runtime.sh",
            "cp /tmp/run_data_asset_api.sh /etc/data-asset/scripts/; chmod +x /etc/data-asset/scripts/run_data_asset_api.sh",
            # fix libclntsh inside running container if possible
            f"docker exec {CONTAINER} bash -lc 'ln -sfn libclntsh.so.19.1 /opt/oracle/libclntsh.so 2>/dev/null || ln -sfn /opt/oracle/instantclient_21/libclntsh.so.21.1 /opt/oracle/libclntsh.so 2>/dev/null; ls -l /opt/oracle/libclntsh.so 2>/dev/null || true'",
            f"docker restart {CONTAINER}",
        ]
        for cmd in cmds:
            code, out, err = run(c, cmd, timeout=120)
            print(cmd[:80], "=>", code, (out or err)[:300])

        time.sleep(8)

        # 2) ensure quality night job
        seed = r"""
from datetime import datetime, timezone
from app.core.db import SessionLocal
from app.models.governance_ops import SchedulerJob
from sqlalchemy import select
db=SessionLocal()
existing=db.scalar(select(SchedulerJob).where(
    SchedulerJob.job_type=='quality_check',
    SchedulerJob.trigger_mode=='scheduled',
    SchedulerJob.schedule_cron=='0 2 * * *',
))
if not existing:
    db.add(SchedulerJob(job_type='quality_check', source_code='platform', trigger_mode='scheduled',
        schedule_cron='0 2 * * *', status='registered', started_at=datetime.now(timezone.utc)))
    db.commit(); print('created_night_job')
else:
    print('exists', existing.id)
rows=db.scalars(select(SchedulerJob).order_by(SchedulerJob.id.desc()).limit(10)).all()
for r in rows:
    print(r.id, r.job_type, r.schedule_cron, r.trigger_mode, r.status)
db.close()
"""
        sftp.putfo(io.BytesIO(seed.encode()), "/tmp/seed_job.py")
        run(c, f"docker cp /tmp/seed_job.py {CONTAINER}:/tmp/seed_job.py")
        code, out, err = run(
            c,
            f"docker exec -e PYTHONPATH=/app -w /app {CONTAINER} python /tmp/seed_job.py",
        )
        print("jobs", out or err)

        # 3) upload 08 and run L10 diff (asset_tables fallback if no column snapshots for ods)
        eight = ROOT / "开发起步包" / "08_数据中心元数据快照.json"
        print("upload 08 size", eight.stat().st_size)
        sftp.put(str(eight), "/tmp/08_meta.json")
        run(c, f"docker cp /tmp/08_meta.json {CONTAINER}:/tmp/08_meta.json")
        code, out, err = run(
            c,
            f"docker exec -e PYTHONPATH=/app -w /app {CONTAINER} python "
            f"/app/scripts/diff_live_snapshot_vs_08.py "
            f"--snapshot-json /tmp/08_meta.json --source-code ods_8_216 "
            f"--use-asset-tables --out /tmp/l10_diff_live_vs_08.json",
            timeout=300,
        )
        print("diff exit", code)
        print((out or "")[:2500])
        if err:
            print("diff err", err[:1500])
        # pull report
        run(c, f"docker cp {CONTAINER}:/tmp/l10_diff_live_vs_08.json /tmp/l10_diff_live_vs_08.json")
        try:
            sftp.get("/tmp/l10_diff_live_vs_08.json", str(ROOT / "开发起步包" / "69_L10活库与08表名差异结果.json"))
            print("saved 69 result json")
        except Exception as e:
            print("pull report failed", e)

        # 4) frontend dist if present
        dist = ROOT / "frontend" / "dist"
        if dist.exists():
            print("sync frontend dist...")
            # tar for speed
            fd, tname = tempfile.mkstemp(suffix=".tar.gz")
            os.close(fd)
            with tarfile.open(tname, "w:gz") as tar:
                tar.add(dist, arcname="dist")
            sftp.put(tname, "/tmp/fe_dist.tar.gz")
            Path(tname).unlink(missing_ok=True)
            run(
                c,
                "mkdir -p /tmp/fe_dist && tar -xzf /tmp/fe_dist.tar.gz -C /tmp/fe_dist && "
                "rsync -a --delete /tmp/fe_dist/dist/ /usr/share/nginx/html/ 2>/dev/null || "
                "cp -a /tmp/fe_dist/dist/. /usr/share/nginx/html/; nginx -s reload 2>/dev/null || true",
            )
            print("frontend synced")

        print("DONE")
    finally:
        sftp.close()
        c.close()


if __name__ == "__main__":
    main()
