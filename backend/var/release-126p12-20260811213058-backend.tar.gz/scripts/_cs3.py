import oracledb, os
try: oracledb.init_oracle_client(lib_dir="/opt/oracle")
except Exception: pass
conn = oracledb.connect(user=os.environ["ODS_8_216_USER"], password=os.environ["ODS_8_216_PASSWORD"], dsn="10.10.8.216:1521/orcl")
conn.call_timeout = 30000
cur = conn.cursor()
cur.execute("SET TRANSACTION READ ONLY")
def run(label, sql):
    try:
        cur.execute(sql)
        rows = cur.fetchmany(20)
        print(f"=== {label} ===")
        for r in rows: print("  ", r)
        if not rows: print("  (无数据)")
    except Exception as e:
        print(f"=== {label} ERR: {e}")

# 1. 0502 在住院检验有没有(任意时间)
run("住院 0502 任意时间", "SELECT count(*) FROM LAB_TEST_MASTER WHERE VISIT_ID>0 AND PERFORMED_BY='0502'")
# 2. 0502 在门诊处方有没有(任意时间, ITEM_CLASS=C)
run("门诊 0502 任意时间 C", "SELECT count(*) FROM OUTP_TREAT_REC WHERE ITEM_CLASS='C' AND PERFORMED_BY='0502'")
# 3. OUTP_TREAT_REC ITEM_NAME 前缀(0502, 门诊)
run("门诊0502 ITEM_NAME前缀", """SELECT substr(ITEM_NAME,1,2) pfx, count(*) FROM OUTP_TREAT_REC
WHERE VISIT_DATE>=ADD_MONTHS(SYSDATE,-6) AND ITEM_CLASS='C' AND PERFORMED_BY='0502'
GROUP BY substr(ITEM_NAME,1,2) ORDER BY 2 DESC""")
# 4. 住院检验 performed_by 实际分布
run("住院 performed_by 分布", "SELECT PERFORMED_BY,count(*) FROM LAB_TEST_MASTER WHERE REQUESTED_DATE_TIME>=ADD_MONTHS(SYSDATE,-1) AND VISIT_ID>0 GROUP BY PERFORMED_BY ORDER BY 2 DESC")
cur.close(); conn.close()
