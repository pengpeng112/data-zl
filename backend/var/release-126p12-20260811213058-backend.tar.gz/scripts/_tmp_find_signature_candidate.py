import base64
from app.core.config import settings
from app.services.his_identity_sync import _connector, _select
from app.services.jhemr_identity_adapter import JhemrIdentityAdapter

his = _connector()
try:
    rows = _select(
        his,
        "SELECT EMPLCODE, SIGNATUREBASE64 FROM FXHIS.SYS_EMPLOYEE_QM "
        "WHERE SIGNATUREBASE64 IS NOT NULL "
        "AND DBMS_LOB.GETLENGTH(SIGNATUREBASE64) > 0 AND ROWNUM <= :max_rows",
        100,
    )
    source = []
    for row in rows:
        emp = str(row.get("EMPLCODE") or "").strip()
        raw = row.get("SIGNATUREBASE64")
        text = raw.read() if hasattr(raw, "read") else str(raw or "")
        encoded = text.split(",", 1)[1] if "," in text else text
        try:
            image = base64.b64decode(encoded, validate=True)
        except Exception:
            image = b""
        if emp and image:
            source.append((emp, image))
finally:
    his.close()

adapter = JhemrIdentityAdapter(
    credential_ref=settings.identity_sync_jhemr_credential_ref,
    hospital_no=settings.identity_sync_jhemr_hospital_no,
    jump_host=settings.his_source_jump_host,
    jump_port=settings.his_source_jump_port,
    jump_user=settings.his_source_jump_user,
    jump_key=settings.his_source_jump_key or None,
    db_host=settings.identity_sync_jhemr_host,
    db_port=settings.identity_sync_jhemr_port,
    db_name=settings.identity_sync_jhemr_dbname,
)
try:
    adapter.connect()
    missing = []
    for emp, image in source:
        row = adapter._fetch_all(
            "SELECT user_id, octet_length(user_name_pic) AS pic_length "
            "FROM jhemr.users_pic WHERE user_id = %s",
            (emp,),
        )
        if not row or not row[0].get("pic_length"):
            user = adapter._fetch_all(
                "SELECT user_id FROM jhemr.users WHERE user_id = %s AND hospital_no = %s",
                (emp, settings.identity_sync_jhemr_hospital_no),
            )
            if user:
                missing.append({"emp_no": emp, "source_length": len(image)})
        if len(missing) >= 5:
            break
    print({"source_count": len(source), "missing_candidates": missing})
finally:
    adapter.close()
