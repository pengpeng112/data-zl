import sys
sys.path.insert(0, '/app')
from app.core.db import SessionLocal
from sqlalchemy import select
from app.models.asset import AssetRelation
from app.api.v1.graph import _nodes_and_edges_for_relations

s = SessionLocal()
rows = s.scalars(select(AssetRelation).limit(120)).all()
nodes, edges, unresolved = _nodes_and_edges_for_relations(s, rows)
ids = [e.id for e in edges]
dups = len(ids) - len(set(ids))
self_loops = sum(1 for e in edges if e.source == e.target)
print(f"nodes={len(nodes)} edges={len(edges)} unresolved={len(unresolved)}")
print(f"重复边ID={dups} 自环边={self_loops}")
# 自环/重复的原因分布
reasons = {}
for rid, reason in unresolved:
    reasons[reason] = reasons.get(reason, 0) + 1
print(f"unresolved 原因分布: {reasons}")
s.close()
