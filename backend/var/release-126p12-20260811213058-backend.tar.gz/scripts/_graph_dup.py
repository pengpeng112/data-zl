import json, urllib.request, sys
sys.path.insert(0, '/app')
from app.core.db import SessionLocal
from sqlalchemy import text
from app.services.auth_service import hash_password

s = SessionLocal(); s.rollback()
TMP = "GraphProbe123!"
old = s.execute(text("SELECT password_hash FROM asset.asset_auth_users WHERE username='platform-admin'")).scalar()
s.execute(text("UPDATE asset.asset_auth_users SET password_hash=:h, must_change_password=false WHERE username='platform-admin'"), {"h": hash_password(TMP)})
s.commit(); s.close()

def post(url, data):
    req = urllib.request.Request(url, data=json.dumps(data).encode(), headers={"Content-Type":"application/json","X-Requested-With":"XMLHttpRequest"})
    return json.loads(urllib.request.urlopen(req, timeout=15).read())

token = post("http://127.0.0.1:8000/api/v1/auth/login", {"username":"platform-admin","password":TMP})["data"]["accessToken"]
req = urllib.request.Request("http://127.0.0.1:8000/api/v1/graph?confidence=A&limit=120", headers={"Authorization":"Bearer "+token,"X-Requested-With":"XMLHttpRequest"})
resp = json.loads(urllib.request.urlopen(req, timeout=30).read())
edges = resp["data"]["edges"]

# 找重复 ID
seen = {}
dups = []
self_loops = []
for e in edges:
    eid = e.get("id")
    if eid in seen:
        dups.append((eid, seen[eid], e))
    else:
        seen[eid] = e
    src, tgt = e.get("source"), e.get("target")
    if src == tgt:
        self_loops.append(e)

print(f"=== 重复边 ID ({len(dups)} 条) ===")
for eid, first, second in dups:
    print(f"  ID={eid}")
    print(f"    第1条: {first.get('source')} -> {first.get('target')} ({first.get('display_source','')} -> {first.get('display_target','')})")
    print(f"    第2条: {second.get('source')} -> {second.get('target')} ({second.get('display_source','')} -> {second.get('display_target','')})")

print(f"\n=== 自环边 ({len(self_loops)} 条) ===")
for e in self_loops:
    print(f"  {e.get('source')} (display: {e.get('display_source','')})")

# 恢复
s2 = SessionLocal()
s2.execute(text("UPDATE asset.asset_auth_users SET password_hash=:h WHERE username='platform-admin'"), {"h": old})
s2.commit(); s2.close()
print("\n密码已恢复")
