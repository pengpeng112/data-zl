"""Harvest ODS.HRP schema metadata (SELECT only) as L12 partial when direct HRP cred missing."""
from __future__ import annotations

import csv
import json
import os
import textwrap
from pathlib import Path

import paramiko

HOST = "10.10.8.83"
PASSWORD = os.environ.get("APP_SSH_PASSWORD", "P@ssw0rd@123")
OUT_DIR = Path(r"F:\python\数据资产\开发起步包\数据资产_HRP源端资产包")


def run(c, cmd, timeout=300):
    _i, o, e = c.exec_command(cmd, timeout=timeout)
    return o.channel.recv_exit_status(), o.read().decode("utf-8", "replace"), e.read().decode("utf-8", "replace")


REMOTE = textwrap.dedent(
    """\
    import json
    from pathlib import Path
    import oracledb

    oracledb.init_oracle_client(lib_dir="/opt/oracle")
    u, p = Path("/etc/data-asset/credentials/ods_8_216").read_text().strip().split(":", 1)
    conn = oracledb.connect(user=u, password=p, dsn="10.10.8.216:1521/orcl")
    cur = conn.cursor()
    try:
        cur.execute("SET TRANSACTION READ ONLY")
    except Exception:
        pass

    out = {"source": "ODS.HRP@10.10.8.216", "mode": "readonly_metadata"}
    cur.execute(
        "SELECT table_name, NVL(num_rows,0), tablespace_name FROM all_tables WHERE owner='HRP' ORDER BY table_name"
    )
    tables = [{"owner": "HRP", "table_name": r[0], "num_rows_stats": r[1], "tablespace": r[2]} for r in cur.fetchall()]
    out["tables"] = tables

    cols = []
    for t in tables:
        cur.execute(
            "SELECT column_name, data_type, data_length, data_precision, data_scale, nullable, column_id "
            "FROM all_tab_columns WHERE owner='HRP' AND table_name=:t ORDER BY column_id",
            t=t["table_name"],
        )
        for r in cur.fetchall():
            cols.append({
                "owner": "HRP",
                "table_name": t["table_name"],
                "column_name": r[0],
                "data_type": r[1],
                "data_length": r[2],
                "data_precision": r[3],
                "data_scale": r[4],
                "nullable": r[5],
                "column_id": r[6],
            })
    out["columns"] = cols

    # probe has_row for core identity tables
    core = ["BD_PSNDOC", "HI_PSNJOB", "ORG_DEPT", "SM_USER", "BD_PSNCL", "HI_PSNDOC_EDU"]
    probes = {}
    for name in core:
        try:
            cur.execute(f"SELECT COUNT(*) FROM HRP.{name} WHERE ROWNUM<=1")
            probes[name] = cur.fetchone()[0]
        except Exception as ex:
            probes[name] = f"ERR:{type(ex).__name__}"
    out["core_has_row"] = probes
    out["table_count"] = len(tables)
    out["column_count"] = len(cols)
    # WA_ presence
    out["wa_tables_in_ods_hrp"] = [t["table_name"] for t in tables if t["table_name"].startswith("WA_")]
    print(json.dumps(out, ensure_ascii=False))
    cur.close(); conn.close()
    """
)


def main() -> None:
    c = paramiko.SSHClient()
    c.set_missing_host_key_policy(paramiko.AutoAddPolicy())
    c.connect(HOST, username="root", password=PASSWORD, timeout=15, allow_agent=False, look_for_keys=False)
    sftp = c.open_sftp()
    with sftp.file("/tmp/hrp_ods_harvest.py", "w") as f:
        f.write(REMOTE)
    sftp.close()

    code, out, err = run(
        c,
        "bash /etc/data-asset/ensure_oracle_ro_runtime.sh >/dev/null; "
        "docker cp /tmp/hrp_ods_harvest.py data-asset-api:/tmp/hrp_ods_harvest.py; "
        "docker exec data-asset-api python /tmp/hrp_ods_harvest.py",
        timeout=180,
    )
    print("exit", code)
    if err:
        print("ERR", err[:1000])
    start = out.find("{")
    end = out.rfind("}")
    if start < 0 or end < start:
        print(out[:3000])
        c.close()
        return
    data = json.loads(out[start : end + 1])
    print("tables", data.get("table_count"), "columns", data.get("column_count"), "wa", data.get("wa_tables_in_ods_hrp"))

    OUT_DIR.mkdir(parents=True, exist_ok=True)
    # write CSV supplements
    tables_path = OUT_DIR / "hrp_ods_mirror_tables.csv"
    cols_path = OUT_DIR / "hrp_ods_mirror_columns.csv"
    summary_path = OUT_DIR / "hrp_ods_mirror_summary.json"

    with tables_path.open("w", encoding="utf-8-sig", newline="") as f:
        w = csv.DictWriter(
            f,
            fieldnames=["source_mirror", "owner", "table_name", "num_rows_stats", "tablespace"],
        )
        w.writeheader()
        for t in data.get("tables") or []:
            w.writerow({
                "source_mirror": "ODS.HRP@10.10.8.216",
                "owner": t.get("owner"),
                "table_name": t.get("table_name"),
                "num_rows_stats": t.get("num_rows_stats"),
                "tablespace": t.get("tablespace"),
            })

    with cols_path.open("w", encoding="utf-8-sig", newline="") as f:
        w = csv.DictWriter(
            f,
            fieldnames=[
                "source_mirror",
                "owner",
                "table_name",
                "column_name",
                "data_type",
                "data_length",
                "data_precision",
                "data_scale",
                "nullable",
                "column_id",
            ],
        )
        w.writeheader()
        for col in data.get("columns") or []:
            row = {"source_mirror": "ODS.HRP@10.10.8.216", **col}
            w.writerow(row)

    summary = {
        "status": "partial",
        "direct_hrp_host": "10.10.10.23:1521/hrpdb",
        "direct_hrp_port_from_8_83": "OPEN",
        "direct_hrp_credential": "missing (need HRP_USER/HRP_PASSWORD or /etc/data-asset/credentials/hrp_10_10_10_23)",
        "jump_8_53_from_8_83": "Permission denied (no key/password)",
        "fallback_mirror": "ODS.HRP@10.10.8.216",
        "table_count": data.get("table_count"),
        "column_count": data.get("column_count"),
        "wa_tables_in_ods_hrp": data.get("wa_tables_in_ods_hrp"),
        "core_has_row": data.get("core_has_row"),
        "files": [tables_path.name, cols_path.name],
        "note": "WA_* 薪酬表不在 ODS.HRP 镜像中，需直连 HRP 源库补采",
    }
    summary_path.write_text(json.dumps(summary, ensure_ascii=False, indent=2), encoding="utf-8")
    print(json.dumps(summary, ensure_ascii=False, indent=2))

    # register HRP system/source on platform (no password yet)
    reg = r"""
sudo -u postgres /usr/local/pgsql/bin/psql -d data_asset -v ON_ERROR_STOP=1 <<'SQL'
INSERT INTO asset.asset_systems (system_code, system_name_cn, system_type, description_cn, status)
VALUES ('HRP', 'HRP/用友NC', 'HRP', '10.10.10.23/hrpdb；当前凭据未配置，已用 ODS.HRP 镜像补字段', 'active')
ON CONFLICT (system_code) DO UPDATE SET
  system_name_cn=EXCLUDED.system_name_cn,
  description_cn=EXCLUDED.description_cn,
  status='active',
  updated_at=now();

INSERT INTO asset.asset_data_sources (
  system_code, source_code, source_name_cn, db_type, host_masked, port, service_name,
  connection_mode, environment, collect_mode, credential_ref, description_cn, enabled,
  last_check_status, last_check_at
) VALUES (
  'HRP', 'hrp_10_10_10_23', 'HRP源端 10.10.10.23/hrpdb', 'oracle', '10.10.10.23', 1521, 'hrpdb',
  'direct', 'prod', 'metadata_only', NULL,
  '端口可达；缺只读凭据。ODS.HRP 镜像字段已补采到资产包 hrp_ods_mirror_*.csv', false,
  'credential_missing', now()
)
ON CONFLICT (source_code) DO UPDATE SET
  description_cn=EXCLUDED.description_cn,
  last_check_status=EXCLUDED.last_check_status,
  last_check_at=EXCLUDED.last_check_at,
  enabled=false,
  updated_at=now();
SQL
"""
    code, out, err = run(c, reg, timeout=30)
    print("=== register HRP source")
    print(out)
    if err and "could not change directory" not in err:
        print("ERR", err[:500])
    c.close()


if __name__ == "__main__":
    main()
