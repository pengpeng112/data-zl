"""Server-side dry-run test for medical dict push (no business DB write by default)."""
from __future__ import annotations

import json
from datetime import datetime, timedelta, timezone

from sqlalchemy import text

from app.core.config import settings
from app.core.db import SessionLocal
from app.services.medical_code_push import (
    apply_one_action,
    check_exists_remote,
    export_platform_preview,
    plan_push_actions,
    push_enabled,
)


def main() -> None:
    print("=== medical push dry-run test ===")
    print("push_enabled:", push_enabled())
    print("default_hospital_no:", getattr(settings, "dict_medical_push_default_hospital_no", None))

    db = SessionLocal()
    try:
        cols = [
            r[0]
            for r in db.execute(
                text(
                    "SELECT column_name FROM information_schema.columns "
                    "WHERE table_schema='asset' AND table_name='asset_dict_medical_code_items' "
                    "ORDER BY ordinal_position"
                )
            ).fetchall()
        ]
        print("item_columns:", cols)

        sets = db.execute(
            text(
                "SELECT code_set_code, category_code, count(*) "
                "FROM asset.asset_dict_medical_code_items GROUP BY 1,2 ORDER BY 1"
            )
        ).fetchall()
        print("items_by_set:", sets)

        runs = db.execute(
            text(
                "SELECT id, batch_code, status, mode, created_at, diagnosis_file_name, operation_file_name "
                "FROM asset.asset_dict_medical_import_runs ORDER BY id DESC LIMIT 5"
            )
        ).fetchall()
        print("import_runs:", runs)

        # Prefer "recent week" if extra has source dates or import exists; else sample known/recent codes.
        since = datetime.now(timezone.utc) - timedelta(days=7)
        recent_codes: list[str] = []

        # If mappings/items have no created_at, use import run window + sample tail + grey sample.
        # Try created_at on mappings table.
        map_cols = [
            r[0]
            for r in db.execute(
                text(
                    "SELECT column_name FROM information_schema.columns "
                    "WHERE table_schema='asset' AND table_name='asset_dict_medical_code_mappings'"
                )
            ).fetchall()
        ]
        print("mapping_columns:", map_cols)
        if "created_at" in map_cols:
            rows = db.execute(
                text(
                    """
                    SELECT DISTINCT from_item_code
                    FROM asset.asset_dict_medical_code_mappings
                    WHERE category_code='diagnosis'
                      AND from_code_set='diagnosis_local_clinical'
                      AND created_at >= :since
                    ORDER BY from_item_code
                    LIMIT 30
                    """
                ),
                {"since": since},
            ).fetchall()
            recent_codes = [r[0] for r in rows]
            print("recent_mapping_codes_7d:", len(recent_codes), recent_codes[:10])

        if not recent_codes:
            # fallback: pick a few active diagnosis codes including grey-like if present
            sample = db.execute(
                text(
                    """
                    SELECT item_code, item_name_cn,
                           extra->>'insurance_raw_code' AS ins,
                           extra->>'insurance_mapping_status' AS st
                    FROM asset.asset_dict_medical_code_items
                    WHERE code_set_code='diagnosis_local_clinical' AND status='active'
                    ORDER BY item_code
                    LIMIT 8
                    """
                )
            ).fetchall()
            grey = db.execute(
                text(
                    """
                    SELECT item_code, item_name_cn,
                           extra->>'insurance_raw_code' AS ins,
                           extra->>'insurance_mapping_status' AS st
                    FROM asset.asset_dict_medical_code_items
                    WHERE code_set_code='diagnosis_local_clinical' AND status='active'
                      AND (
                        extra->>'insurance_raw_code' = '灰码'
                        OR extra->>'insurance_mapping_status' = 'source_marker_not_mapping'
                        OR extra->>'insurance_raw_name' = '灰码'
                      )
                    ORDER BY item_code
                    LIMIT 3
                    """
                )
            ).fetchall()
            print("sample_diag:", [(r[0], (r[1] or "")[:24], r[2], r[3]) for r in sample])
            print("grey_diag:", [(r[0], (r[1] or "")[:24], r[2], r[3]) for r in grey])
            recent_codes = [r[0] for r in sample[:5]]
            for r in grey:
                if r[0] not in recent_codes:
                    recent_codes.append(r[0])

        if not recent_codes:
            print("NO_PLATFORM_ITEMS: cannot plan")
            return

        hospital_no = getattr(settings, "dict_medical_push_default_hospital_no", "1110002") or "1110002"
        preview = export_platform_preview(
            db, category_code="diagnosis", item_codes=recent_codes, max_items=50
        )
        print("export_preview_total:", preview["total"])
        for it in preview["items"][:5]:
            print(
                "  preview",
                it["local_code"],
                "grey=",
                it["is_grey_insurance"],
                "ybhm=",
                it["ybhm_to_write"],
                "contrast=",
                it["write_contrast"],
            )

        plan = plan_push_actions(
            db,
            category_code="diagnosis",
            targets=["HIS_SOURCE", "JHEMR_VASTBASE"],
            item_codes=recent_codes,
            max_items=50,
            hospital_no=hospital_no,
            include_jhdict=True,
        )
        print("plan_summary:", json_safe(plan["summary"]))
        print("plan_action_count:", plan["action_count"])
        by_table: dict[str, int] = {}
        for a in plan["actions"]:
            by_table[a["target_table"]] = by_table.get(a["target_table"], 0) + 1
        print("plan_by_table:", by_table)

        # optional remote existence check if sources registered
        his_src = db.execute(
            text(
                "SELECT source_code FROM asset.asset_data_sources "
                "WHERE system_code ILIKE '%HIS%' OR source_code ILIKE '%his%' "
                "ORDER BY id LIMIT 5"
            )
        ).fetchall()
        jh_src = db.execute(
            text(
                "SELECT source_code FROM asset.asset_data_sources "
                "WHERE system_code ILIKE '%JHEMR%' OR source_code ILIKE '%jhemr%' OR db_type='vastbase' "
                "ORDER BY id LIMIT 5"
            )
        ).fetchall()
        print("his_sources:", his_src)
        print("jhemr_sources:", jh_src)
        his_code = his_src[0][0] if his_src else None
        jh_code = jh_src[0][0] if jh_src else None

        checked = []
        if his_code or jh_code:
            for a in plan["actions"][:12]:
                try:
                    ca = check_exists_remote(
                        db,
                        a,
                        his_source_code=his_code,
                        jhemr_source_code=jh_code,
                    )
                    checked.append(
                        {
                            "table": ca.get("target_table"),
                            "code": ca.get("item_code"),
                            "status": ca.get("plan_status"),
                            "remote_checked": ca.get("remote_checked"),
                            "remote_rows": ca.get("remote_rows"),
                            "reason": ca.get("reason"),
                        }
                    )
                except Exception as exc:
                    checked.append(
                        {
                            "table": a.get("target_table"),
                            "code": a.get("item_code"),
                            "error": type(exc).__name__ + ":" + str(exc)[:120],
                        }
                    )
            print("remote_check_sample:", json_safe(checked))

        # dry-run first planned insert action
        planned = [a for a in plan["actions"] if a.get("plan_status") == "planned"]
        if planned:
            dry = apply_one_action(db, planned[0], mode="dry_run", operator="server_test")
            print(
                "dry_run_one:",
                dry.get("status"),
                dry.get("mode"),
                dry.get("executed"),
                dry.get("target_table"),
                dry.get("item_code"),
            )
        else:
            print("no planned actions to dry-run (all skipped/blocked?)")

        # also plan one operation sample if available
        op_codes = db.execute(
            text(
                """
                SELECT item_code FROM asset.asset_dict_medical_code_items
                WHERE code_set_code='operation_local_clinical' AND status='active'
                ORDER BY item_code LIMIT 3
                """
            )
        ).fetchall()
        if op_codes:
            op_plan = plan_push_actions(
                db,
                category_code="operation",
                targets=["HIS_SOURCE", "JHEMR_VASTBASE"],
                item_codes=[r[0] for r in op_codes],
                max_items=10,
                hospital_no=hospital_no,
            )
            print("operation_plan_summary:", json_safe(op_plan["summary"]))
            print("operation_action_count:", op_plan["action_count"])

        print("BUSINESS_WRITE: 0 (dry_run only)")
        print("TEST_OK")
    finally:
        db.close()


def json_safe(obj):
    return json.dumps(obj, ensure_ascii=False, default=str)


if __name__ == "__main__":
    main()
