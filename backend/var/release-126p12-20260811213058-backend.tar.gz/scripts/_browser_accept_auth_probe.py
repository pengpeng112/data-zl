"""Mint JWT inside container (no password change) and probe SPA-critical APIs."""
from __future__ import annotations

import io
import json
import os

import paramiko

HOST = os.environ.get("APP_SSH_HOST", "10.10.8.83")
PASSWORD = os.environ.get("APP_SSH_PASSWORD", "P@ssw0rd@123")
CONTAINER = "data-asset-api"

MINT = r"""
from app.core.db import SessionLocal
from app.models.auth import AuthUser
from app.services.auth_service import create_access_token
from sqlalchemy import select
db=SessionLocal()
user=db.scalar(select(AuthUser).where(AuthUser.enabled==True).order_by(AuthUser.id.asc()).limit(1))
if not user:
    user=db.scalar(select(AuthUser).order_by(AuthUser.id.asc()).limit(1))
assert user, 'no auth user'
token, exp = create_access_token(user)
print(user.username)
print(token)
print(exp.isoformat())
db.close()
"""


def run(c, cmd, timeout=90):
    _, o, e = c.exec_command(cmd, timeout=timeout)
    return o.channel.recv_exit_status(), o.read().decode("utf-8", "replace"), e.read().decode("utf-8", "replace")


def main():
    c = paramiko.SSHClient()
    c.set_missing_host_key_policy(paramiko.AutoAddPolicy())
    c.connect(HOST, username="root", password=PASSWORD, timeout=20, allow_agent=False, look_for_keys=False)
    sftp = c.open_sftp()
    try:
        sftp.putfo(io.BytesIO(MINT.encode()), "/tmp/mint_token.py")
        run(c, f"docker cp /tmp/mint_token.py {CONTAINER}:/tmp/mint_token.py")
        code, out, err = run(
            c,
            f"docker exec -e PYTHONPATH=/app -w /app {CONTAINER} python /tmp/mint_token.py",
        )
        if code != 0:
            print("mint failed", out, err)
            return
        lines = [ln.strip() for ln in out.splitlines() if ln.strip()]
        username, token = lines[0], lines[1]
        print("user", username, "token_len", len(token))

        paths = [
            "/api/v1/dashboard/summary",
            "/api/v1/assets/tree",
            "/api/v1/tables?page=1&page_size=5",
            "/api/v1/tables/HIS/PAT_VISIT/columns",
            "/api/v1/identity/sync-diffs?status=open&page=1&page_size=3",
            "/api/v1/identity/sync-diffs?status=open&diff_type=field_mismatch&page=1&page_size=3",
            "/api/v1/quality/findings?page=1&page_size=3",
            "/api/v1/quality/findings?run_id=1&page=1&page_size=3",
            "/api/v1/quality/checks/runs?page=1&page_size=3",
            "/api/v1/quality/summary",
            "/api/v1/relations?page=1&page_size=5",
            "/api/v1/identity/persons?page=1&page_size=3",
            "/api/v1/identity/change-requests?page=1&page_size=5",
            "/api/v1/systems",
            "/api/v1/health",
            "/health",
        ]
        results = []
        for base in ["http://127.0.0.1", "http://127.0.0.1:8000"]:
            for path in paths:
                cmd = (
                    f"curl -sS -H 'Authorization: Bearer {token}' "
                    f"-o /tmp/ba.json -w '%{{http_code}}' '{base}{path}'"
                )
                code, http, err = run(c, cmd)
                body_code, body, _ = run(
                    c,
                    "python3 - <<'PY'\n"
                    "import json\n"
                    "p='/tmp/ba.json'\n"
                    "raw=open(p,'rb').read()\n"
                    "try:\n"
                    " d=json.loads(raw.decode('utf-8','replace'))\n"
                    "except Exception as e:\n"
                    " print(json.dumps({'parse_err':str(e),'raw':raw[:160].decode('utf-8','replace')}))\n"
                    " raise SystemExit\n"
                    "out={'code':d.get('code'),'message':d.get('message')}\n"
                    "data=d.get('data')\n"
                    "if isinstance(data, dict):\n"
                    " out['data_keys']=list(data.keys())[:15]\n"
                    " if 'items' in data: out['items']=len(data.get('items') or []); out['total']=data.get('total')\n"
                    " if 'tables' in data and not isinstance(data.get('tables'), list): out['tables']=data.get('tables')\n"
                    " if 'assets' in data: out['assets']=data.get('assets')\n"
                    "elif isinstance(data, list):\n"
                    " out['data_len']=len(data)\n"
                    " if data and isinstance(data[0], dict): out['item0_keys']=list(data[0].keys())[:12]\n"
                    "print(json.dumps(out, ensure_ascii=False)[:500])\n"
                    "PY",
                )
                rec = {
                    "base": base,
                    "path": path,
                    "http": http.strip(),
                    "body": body.strip()[:500],
                }
                results.append(rec)
                print(json.dumps(rec, ensure_ascii=False))
            # only need one successful base fully if nginx works
            if any(r["base"] == base and r["http"] == "200" for r in results):
                # still collect both for compare of health
                pass
        # SPA static asset referenced by index
        code, out, err = run(
            c,
            "python3 - <<'PY'\n"
            "import re,os\n"
            "html=open('/usr/share/nginx/html/index.html',encoding='utf-8').read()\n"
            "refs=re.findall(r'(?:src|href)=\"([^\"]+)\"', html)\n"
            "print('refs', refs[:20])\n"
            "for r in refs:\n"
            " p='/usr/share/nginx/html'+r if r.startswith('/') else '/usr/share/nginx/html/'+r\n"
            " print(r, 'OK' if os.path.exists(p) else 'MISSING')\n"
            "PY",
        )
        print("spa_refs", out)
    finally:
        sftp.close()
        c.close()


if __name__ == "__main__":
    main()
