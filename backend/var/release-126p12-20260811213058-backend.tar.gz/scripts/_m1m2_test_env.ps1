$env:APP_TEST_DB_URL = "postgresql+psycopg://asset_app:admin123@127.0.0.1:55432/data_asset_test"
$env:APP_ENV = "test"
$env:APP_RATE_LIMIT_ENABLED = "false"
$env:APP_JWT_SECRET = "test-only-jwt-secret-not-for-prod"
