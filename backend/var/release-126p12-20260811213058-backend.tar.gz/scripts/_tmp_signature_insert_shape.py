from app.core.config import settings
from app.services.jhemr_identity_adapter import JhemrIdentityAdapter

a = JhemrIdentityAdapter(
    credential_ref=settings.identity_sync_jhemr_credential_ref,
    hospital_no=settings.identity_sync_jhemr_hospital_no,
    jump_host=settings.his_source_jump_host,
    jump_port=settings.his_source_jump_port,
    jump_user=settings.his_source_jump_user,
    jump_key=settings.his_source_jump_key or None,
    db_host=settings.identity_sync_jhemr_host,
    db_port=settings.identity_sync_jhemr_port,
    db_name=settings.identity_sync_jhemr_dbname,
)
try:
    a.connect()
    user = a._fetch_all(
        "SELECT user_id, user_name FROM jhemr.users WHERE user_id = %s AND hospital_no = %s",
        ("003719", settings.identity_sync_jhemr_hospital_no),
    )
    sample = a._fetch_all(
        "SELECT user_id, user_name, user_pic_pwd, create_date, use_flag, "
        "extension_file_name, hospital_no, ca_type "
        "FROM jhemr.users_pic WHERE user_name_pic IS NOT NULL "
        "AND octet_length(user_name_pic) > 0 ORDER BY user_id LIMIT 3",
        (),
    )
    print({"user": user, "sample": sample})
finally:
    a.close()
