"""Hot deploy tree performance + L16 batch to 8.83 and smoke APIs."""
from __future__ import annotations

import io
import json
import os
import tarfile
import tempfile
import time
from pathlib import Path

import paramiko

ROOT = Path(__file__).resolve().parents[2]
HOST = os.environ.get("APP_SSH_HOST", "10.10.8.83")
PASSWORD = os.environ.get("APP_SSH_PASSWORD", "P@ssw0rd@123")
CONTAINER = "data-asset-api"


def run(c, cmd, timeout=300):
    _, o, e = c.exec_command(cmd, timeout=timeout)
    return o.channel.recv_exit_status(), o.read().decode("utf-8", "replace"), e.read().decode("utf-8", "replace")


def main():
    c = paramiko.SSHClient()
    c.set_missing_host_key_policy(paramiko.AutoAddPolicy())
    c.connect(HOST, username="root", password=PASSWORD, timeout=20, allow_agent=False, look_for_keys=False)
    sftp = c.open_sftp()
    try:
        for local, remote in [
            (ROOT / "backend/app/api/v1/systems.py", "/tmp/systems.py"),
            (ROOT / "backend/app/api/v1/identity.py", "/tmp/identity.py"),
        ]:
            sftp.put(str(local), remote)
        run(
            c,
            f"docker cp /tmp/systems.py {CONTAINER}:/app/app/api/v1/systems.py; "
            f"docker cp /tmp/identity.py {CONTAINER}:/app/app/api/v1/identity.py; "
            f"docker restart {CONTAINER}",
        )
        time.sleep(8)

        dist = ROOT / "frontend" / "dist"
        if dist.exists():
            fd, tname = tempfile.mkstemp(suffix=".tar.gz")
            os.close(fd)
            with tarfile.open(tname, "w:gz") as tar:
                tar.add(dist, arcname="dist")
            sftp.put(tname, "/tmp/fe_tree_l16.tar.gz")
            Path(tname).unlink(missing_ok=True)
            run(
                c,
                "mkdir -p /tmp/fe_tl && tar -xzf /tmp/fe_tree_l16.tar.gz -C /tmp/fe_tl && "
                "rsync -a --delete /tmp/fe_tl/dist/ /usr/share/nginx/html/ 2>/dev/null || "
                "cp -a /tmp/fe_tl/dist/. /usr/share/nginx/html/; nginx -s reload 2>/dev/null || true",
            )

        mint = (
            "from app.core.db import SessionLocal\n"
            "from app.models.auth import AuthUser\n"
            "from app.services.auth_service import create_access_token\n"
            "from sqlalchemy import select\n"
            "db=SessionLocal()\n"
            "u=db.scalar(select(AuthUser).where(AuthUser.enabled==True).limit(1))\n"
            "t,_=create_access_token(u); print(t); db.close()\n"
        )
        sftp.putfo(io.BytesIO(mint.encode()), "/tmp/mint_tl.py")
        run(c, f"docker cp /tmp/mint_tl.py {CONTAINER}:/tmp/mint_tl.py")
        code, out, err = run(
            c, f"docker exec -e PYTHONPATH=/app -w /app {CONTAINER} python /tmp/mint_tl.py"
        )
        token = out.strip().splitlines()[-1]
        paths = [
            "/api/v1/assets/tree",
            "/api/v1/assets/tree?include_tables=false",
            "/api/v1/assets/tree/tables?source_code=ods_8_216&schema_name=HIS&page_size=5",
            "/api/v1/assets/tree/search?keyword=PAT_VISIT&limit=5",
            "/api/v1/identity/sync-diffs?status=open&page=1&page_size=3",
        ]
        for path in paths:
            code, http, err = run(
                c,
                f"curl -sS -H 'Authorization: Bearer {token}' -o /tmp/tl.json -w '%{{http_code}}' "
                f"'http://127.0.0.1:8000{path}'",
            )
            _, body, _ = run(
                c,
                "python3 - <<'PY'\n"
                "import json,os\n"
                "raw=open('/tmp/tl.json',encoding='utf-8').read()\n"
                "d=json.loads(raw)\n"
                "data=d.get('data')\n"
                "if isinstance(data,list):\n"
                "  print('list',len(data))\n"
                "  if data:\n"
                "    n=data[0]\n"
                "    schemas=n.get('schemas') or []\n"
                "    t0=schemas[0] if schemas else {}\n"
                "    print('src',n.get('source_code'),'tables_embedded',n.get('tables_embedded'),"
                "'schema0_tables',len(t0.get('tables') or []),'tc',t0.get('table_count'))\n"
                "elif isinstance(data,dict):\n"
                "  print({k:data.get(k) for k in list(data)[:8]})\n"
                "  if 'items' in data: print('items',len(data['items']), 'total',data.get('total'))\n"
                "print(raw[:180])\n"
                "PY",
            )
            print(path, "http", http.strip())
            print(body[:400])
        # batch propose dry smoke: empty ids should 400
        code, http, err = run(
            c,
            f"curl -sS -H 'Authorization: Bearer {token}' -H 'Content-Type: application/json' "
            f"-d '{{\"diff_ids\":[]}}' -o /tmp/tl.json -w '%{{http_code}}' "
            f"http://127.0.0.1:8000/api/v1/identity/sync-diffs/batch-propose-master",
        )
        print("batch empty", http.strip())
    finally:
        sftp.close()
        c.close()


if __name__ == "__main__":
    main()
