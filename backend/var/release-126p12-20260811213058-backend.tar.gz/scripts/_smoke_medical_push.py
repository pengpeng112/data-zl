"""Local smoke for medical_code_push pure logic (no DB)."""
from app.services.medical_code_push import (
    validate_push_sql,
    _is_grey_insurance,
    build_jhemr_diagnosis_dict_insert,
    build_his_diagnosis_insert,
    build_stop_action,
    build_jhemr_diagnosis_contrast_insert,
    build_his_operation_insert,
    build_jhemr_operation_dict_insert,
)


def expect_fail(fn, *args, **kwargs):
    try:
        fn(*args, **kwargs)
        raise AssertionError("expected failure")
    except ValueError as exc:
        print("ok fail:", exc)


expect_fail(
    validate_push_sql,
    "INSERT INTO COMM.DIAGNOSIS_DICT (DIAGNOSIS_CODE) VALUES (:a), (:b)",
    action_type="insert",
    target_table="COMM.DIAGNOSIS_DICT",
)
expect_fail(
    validate_push_sql,
    "UPDATE COMM.DIAGNOSIS_DICT SET STOP_FLAG=1 WHERE DIAGNOSIS_CODE IN ('A','B')",
    action_type="stop",
    target_table="COMM.DIAGNOSIS_DICT",
)
expect_fail(
    validate_push_sql,
    "UPDATE COMM.DIAGNOSIS_DICT SET DIAGNOSIS_NAME='x' WHERE DIAGNOSIS_CODE=:c",
    action_type="stop",
    target_table="COMM.DIAGNOSIS_DICT",
)

assert _is_grey_insurance("灰码", "", "")
assert _is_grey_insurance("", "灰码", "")
assert _is_grey_insurance("x", "y", "source_marker_not_mapping")
assert not _is_grey_insurance("I63.001", "名", "valid")

row = {
    "local_code": "I63.800",
    "local_name": "脑梗死，其他的",
    "dict_attribute": "院内扩展",
    "national_code": "I63.800",
    "national_name": "脑梗死，其他的",
    "insurance_code": "灰码",
    "insurance_name": "",
    "is_grey_insurance": True,
    "ybhm_to_write": "灰码",
    "write_contrast": False,
    "mtb_code": "",
    "mtb_name": "",
    "icd_lr_code": "",
    "icd_lr_name": "",
    "infectious_name": "",
    "operation_level": "四",
    "operation_category": "手术",
    "level4_flag": "是",
    "mini_flag": "",
    "limit_flag": "",
}
a = build_jhemr_diagnosis_dict_insert(row, "H1")
assert a.params["ybhm"] == "灰码"
assert build_jhemr_diagnosis_contrast_insert(row) is None
h = build_his_diagnosis_insert(row)
validate_push_sql(h.sql, action_type="insert", target_table=h.target_table)
s = build_stop_action(category_code="diagnosis", target_system="HIS_SOURCE", item_code="I63.800")
validate_push_sql(s.sql, action_type="stop", target_table=s.target_table)

op = {
    **row,
    "local_code": "00.7000x001L",
    "local_name": "左侧髋关节假体翻修术",
    "national_code": "00.7000x001",
    "national_name": "全髋关节假体翻修术",
    "insurance_code": "00.7000x001",
    "insurance_name": "全髋关节假体翻修术",
    "is_grey_insurance": False,
    "ybhm_to_write": None,
    "write_contrast": True,
}
ho = build_his_operation_insert(op)
validate_push_sql(ho.sql, action_type="insert", target_table=ho.target_table)
jo = build_jhemr_operation_dict_insert(op, "H1")
validate_push_sql(jo.sql, action_type="insert", target_table=jo.target_table)
print("ALL_UNIT_OK")
