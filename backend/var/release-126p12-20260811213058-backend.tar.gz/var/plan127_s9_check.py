"""S9 smoke: test DB connectivity and alembic version."""
from sqlalchemy import create_engine, text

URL = "postgresql+psycopg://postgres:admin123@127.0.0.1:15432/data_asset_test"
e = create_engine(URL)
with e.connect() as c:
    print("db", c.execute(text("select current_database()")).scalar())
    ver = None
    for schema in ("public", "asset"):
        q = text(
            "select version_num from alembic_version"
            if schema == "public"
            else "select version_num from asset.alembic_version"
        )
        try:
            # detect table
            reg = c.execute(
                text("select to_regclass(:n)"),
                {"n": "alembic_version" if schema == "public" else "asset.alembic_version"},
            ).scalar()
            if reg:
                ver = c.execute(q).scalar()
                break
        except Exception as exc:
            c.rollback()
            print("lookup", schema, type(exc).__name__)
    print("alembic", ver)
    # counts
    for label, sql in [
        ("rules", "select count(*) from asset.asset_quality_rules"),
        ("reviews", "select count(*) from asset.asset_relation_reviews"),
        ("relations", "select count(*) from asset.asset_relations"),
        ("recipes", "select count(*) from asset.asset_relation_recipes"),
    ]:
        try:
            print(label, c.execute(text(sql)).scalar())
        except Exception as exc:
            c.rollback()
            print(label, "ERR", type(exc).__name__)
