"""S9: verify review approve links formal (not candidate) without pytest fixtures."""
from __future__ import annotations

import os
import sys
from pathlib import Path

os.environ["APP_TEST_DB_URL"] = (
    "postgresql+psycopg://postgres:admin123@127.0.0.1:15432/data_asset_test"
)
os.environ["APP_DB_URL"] = os.environ["APP_TEST_DB_URL"]
os.environ["APP_ENV"] = "test"
os.environ.setdefault("APP_JWT_SECRET", "test-only-jwt-secret-not-for-prod")
os.environ.setdefault("APP_RATE_LIMIT_ENABLED", "false")

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from sqlalchemy import delete, select

from app.core.db import SessionLocal
from app.models.asset import AssetRelation, AssetRelationReview
from app.services.relation_identity import populate_endpoint_fields
from app.services.relation_review_service import approve_review, reject_review


def main() -> int:
    db = SessionLocal()
    try:
        # Clean only plan127 rows
        db.execute(delete(AssetRelationReview).where(AssetRelationReview.source_evidence.like("plan127%")))
        db.execute(delete(AssetRelation).where(AssetRelation.note.like("plan127%")))
        db.commit()

        formal = AssetRelation(
            from_table="INPBILL.INP_BILL_DETAIL",
            from_columns="PATIENT_ID,VISIT_ID",
            to_table="MEDREC.PAT_VISIT",
            to_columns="PATIENT_ID,VISIT_ID",
            join_condition="a",
            confidence="A",
            validation_status="verified",
            relation_layer="formal",
            note="plan127 formal bill",
        )
        populate_endpoint_fields(db, formal)
        cand = AssetRelation(
            from_table="HIS.INP_BILL_DETAIL",
            from_columns="PATIENT_ID,VISIT_ID",
            to_table="HIS.PAT_VISIT",
            to_columns="PATIENT_ID,VISIT_ID",
            join_condition="b",
            confidence="B",
            validation_status="sample_pass",
            relation_layer="candidate",
            note="plan127 candidate bill",
        )
        populate_endpoint_fields(db, cand)
        formal2 = AssetRelation(
            from_table="OUTPADM.CLINIC_MASTER",
            from_columns="PATIENT_ID",
            to_table="MEDREC.PAT_MASTER_INDEX",
            to_columns="PATIENT_ID",
            join_condition="c",
            confidence="A",
            validation_status="verified",
            relation_layer="formal",
            note="plan127 formal clinic",
        )
        populate_endpoint_fields(db, formal2)
        cand2 = AssetRelation(
            from_table="HIS.CLINIC_MASTER",
            from_columns="PATIENT_ID",
            to_table="HIS.PAT_MASTER_INDEX",
            to_columns="PATIENT_ID",
            join_condition="d",
            confidence="B",
            validation_status="sample_pass",
            relation_layer="candidate",
            note="plan127 candidate clinic",
        )
        populate_endpoint_fields(db, cand2)
        db.add_all([formal, cand, formal2, cand2])
        db.flush()

        r1 = AssetRelationReview(
            from_table="HIS.INP_BILL_DETAIL",
            from_columns="PATIENT_ID,VISIT_ID",
            to_table="HIS.PAT_VISIT",
            to_columns="PATIENT_ID,VISIT_ID",
            review_status="draft",
            source_evidence="plan127 review1",
        )
        r2 = AssetRelationReview(
            from_table="HIS.CLINIC_MASTER",
            from_columns="PATIENT_ID",
            to_table="HIS.PAT_MASTER_INDEX",
            to_columns="PATIENT_ID",
            review_status="draft",
            source_evidence="plan127 review2",
            review_note="保留1条孤儿说明",
        )
        r3 = AssetRelationReview(
            from_table="MEDREC.PAT_VISIT",
            from_columns="PATIENT_ID,VISIT_ID",
            to_table="HIS.PAT_VISIT",
            to_columns="PATIENT_ID,VISIT_ID",
            review_status="draft",
            source_evidence="plan127 review3",
        )
        db.add_all([r1, r2, r3])
        db.commit()
        for obj in (formal, cand, formal2, cand2, r1, r2, r3):
            db.refresh(obj)

        print("seeded formal", formal.id, "cand", cand.id, "reviews", r1.id, r2.id, r3.id)

        a1 = approve_review(db, r1, reviewer="s9", note="A14")
        db.commit()
        print("A14", a1)
        assert a1["ok"] and a1["action"] == "linked_formal"
        assert a1["source_relation_id"] == formal.id
        assert a1["source_relation_id"] != cand.id
        db.refresh(cand)
        assert (cand.relation_layer or "").lower() == "candidate"

        a2 = approve_review(db, r2, reviewer="s9", note="A15")
        db.commit()
        print("A15", a2)
        assert a2["ok"] and a2["source_relation_id"] == formal2.id
        assert a2["source_relation_id"] != cand2.id
        db.refresh(r2)
        assert "孤儿" in (r2.review_note or "")

        db.refresh(r3)
        assert r3.review_status == "draft"
        print("A16 draft_ok", r3.id, r3.review_status)

        # list counts
        total = db.scalar(select(AssetRelationReview.id).where(AssetRelationReview.source_evidence.like("plan127%")).count() if False else select(AssetRelationReview).where(AssetRelationReview.source_evidence.like("plan127%")))
        rows = db.scalars(select(AssetRelationReview).where(AssetRelationReview.source_evidence.like("plan127%"))).all()
        print("review_statuses", [(r.id, r.review_status, r.source_relation_id) for r in rows])

        print("REVIEW_FLOW_PASS")
        return 0
    except Exception as exc:
        db.rollback()
        print("REVIEW_FLOW_FAIL", type(exc).__name__, exc)
        return 1
    finally:
        db.close()


if __name__ == "__main__":
    raise SystemExit(main())
