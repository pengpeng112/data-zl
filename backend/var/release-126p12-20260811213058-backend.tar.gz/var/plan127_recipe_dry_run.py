"""127 S7/S9: recipe import dry-run then optional apply on test DB only."""
from __future__ import annotations

import json
import os
import sys
from pathlib import Path

# Force test URL before app import
os.environ.setdefault(
    "APP_TEST_DB_URL",
    "postgresql+psycopg://postgres:admin123@127.0.0.1:15432/data_asset_test",
)
os.environ["APP_DB_URL"] = os.environ["APP_TEST_DB_URL"]
os.environ.setdefault("APP_ENV", "test")

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from scripts.import_relation_recipes import import_recipes, recipes_seed_path


def main():
    path = recipes_seed_path()
    print("seed_path", path, "exists", path.exists())
    if path.exists():
        data = json.loads(path.read_text(encoding="utf-8"))
        print("seed_count", len(data))
        # Prefer 53-confirmed exam recipes if present
        ids = [d.get("recipe_id") for d in data if d.get("recipe_id")]
        print("sample_ids", ids[:8])

    dry = import_recipes(dry_run=True)
    print("dry_run", dry)

    apply_flag = "--apply" in sys.argv
    if apply_flag:
        # Prefer exam/report related if filterable
        only = None
        if path.exists():
            preferred = []
            for d in json.loads(path.read_text(encoding="utf-8")):
                rid = (d.get("recipe_id") or "")
                desc = (d.get("description") or "") + (d.get("domain") or "")
                blob = (rid + desc).lower()
                if any(k in blob for k in ("exam", "检查", "影像", "report", "pacs")):
                    preferred.append(rid)
            if preferred:
                only = set(preferred[:5])
                print("apply_only", only)
        result = import_recipes(dry_run=False, only_recipe_ids=only)
        print("apply", result)
        # idempotent second pass
        again = import_recipes(dry_run=False, only_recipe_ids=only)
        print("apply_again", again)
    else:
        print("skip_apply (pass --apply to write test DB)")


if __name__ == "__main__":
    main()
